import { eq } from "drizzle-orm";
import { db } from "./db";
import { 
  users, agents, agentTemplates, agentTasks,
  type User, type Agent, type AgentTemplate, type AgentTask,
  type InsertUser, type InsertAgent, type InsertAgentTemplate, type InsertAgentTask,
} from "@shared/schema";
import { 
  swarms, swarmParticipants, zkProofs, reputationScores, negotiations,
  type Swarm, type SwarmParticipant, type ZkProof, type ReputationScore, type Negotiation,
  type InsertSwarm, type InsertSwarmParticipant, type InsertZkProof, 
  type InsertReputationScore, type InsertNegotiation
} from "@shared/schema-extensions";
import { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByWallet(walletAddress: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.walletAddress, walletAddress));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Agent operations
  async getAgent(id: number): Promise<Agent | undefined> {
    const [agent] = await db.select().from(agents).where(eq(agents.id, id));
    return agent;
  }

  async getAgentsByUser(userId: number): Promise<Agent[]> {
    return db.select().from(agents).where(eq(agents.userId, userId));
  }

  async getActiveAgents(): Promise<Agent[]> {
    return db.select().from(agents).where(eq(agents.status, "active"));
  }

  async createAgent(insertAgent: InsertAgent): Promise<Agent> {
    const [agent] = await db
      .insert(agents)
      .values(insertAgent)
      .returning();
    return agent;
  }

  async updateAgent(id: number, updates: Partial<Agent>): Promise<Agent | undefined> {
    const [agent] = await db
      .update(agents)
      .set(updates)
      .where(eq(agents.id, id))
      .returning();
    return agent;
  }

  async deleteAgent(id: number): Promise<boolean> {
    await db.delete(agents).where(eq(agents.id, id));
    return true;
  }

  // Agent Template operations
  async getAgentTemplate(id: number): Promise<AgentTemplate | undefined> {
    const [template] = await db.select().from(agentTemplates).where(eq(agentTemplates.id, id));
    return template;
  }

  async getAllAgentTemplates(): Promise<AgentTemplate[]> {
    return db.select().from(agentTemplates);
  }

  async getPopularAgentTemplates(limit: number): Promise<AgentTemplate[]> {
    return db.select().from(agentTemplates).where(eq(agentTemplates.isPopular, true)).limit(limit);
  }

  async createAgentTemplate(template: InsertAgentTemplate): Promise<AgentTemplate> {
    const [agentTemplate] = await db
      .insert(agentTemplates)
      .values(template)
      .returning();
    return agentTemplate;
  }

  async updateAgentTemplate(id: number, updates: Partial<AgentTemplate>): Promise<AgentTemplate | undefined> {
    const [template] = await db
      .update(agentTemplates)
      .set(updates)
      .where(eq(agentTemplates.id, id))
      .returning();
    return template;
  }

  async incrementTemplateDownloads(id: number): Promise<AgentTemplate | undefined> {
    // First get current downloads
    const [currentTemplate] = await db
      .select()
      .from(agentTemplates)
      .where(eq(agentTemplates.id, id));
    
    if (!currentTemplate) return undefined;
    
    // Then increment
    const [template] = await db
      .update(agentTemplates)
      .set({ downloads: (currentTemplate.downloads || 0) + 1 })
      .where(eq(agentTemplates.id, id))
      .returning();
    return template;
  }

  // Agent Task operations
  async getAgentTasks(agentId: number): Promise<AgentTask[]> {
    return db.select().from(agentTasks).where(eq(agentTasks.agentId, agentId));
  }

  async createAgentTask(task: InsertAgentTask): Promise<AgentTask> {
    const [agentTask] = await db
      .insert(agentTasks)
      .values(task)
      .returning();
    return agentTask;
  }

  async updateAgentTask(id: number, updates: Partial<AgentTask>): Promise<AgentTask | undefined> {
    const [task] = await db
      .update(agentTasks)
      .set(updates)
      .where(eq(agentTasks.id, id))
      .returning();
    return task;
  }

  // Multi-Agent Swarm operations
  async getSwarm(id: number): Promise<Swarm | undefined> {
    const [swarm] = await db.select().from(swarms).where(eq(swarms.id, id));
    return swarm;
  }

  async getSwarms(creatorId?: number): Promise<Swarm[]> {
    if (creatorId) {
      return db.select().from(swarms).where(eq(swarms.creatorId, creatorId));
    }
    return db.select().from(swarms);
  }

  async createSwarm(swarm: InsertSwarm): Promise<Swarm> {
    const [newSwarm] = await db
      .insert(swarms)
      .values(swarm)
      .returning();
    return newSwarm;
  }

  async updateSwarm(id: number, updates: Partial<Swarm>): Promise<Swarm | undefined> {
    const [swarm] = await db
      .update(swarms)
      .set(updates)
      .where(eq(swarms.id, id))
      .returning();
    return swarm;
  }

  async deleteSwarm(id: number): Promise<boolean> {
    await db.delete(swarms).where(eq(swarms.id, id));
    return true;
  }

  // Swarm Participants operations
  async getSwarmParticipants(swarmId: number): Promise<SwarmParticipant[]> {
    return db.select().from(swarmParticipants).where(eq(swarmParticipants.swarmId, swarmId));
  }

  async addParticipantToSwarm(participant: InsertSwarmParticipant): Promise<SwarmParticipant> {
    const [newParticipant] = await db
      .insert(swarmParticipants)
      .values(participant)
      .returning();
    return newParticipant;
  }

  async removeParticipantFromSwarm(id: number): Promise<boolean> {
    await db.delete(swarmParticipants).where(eq(swarmParticipants.id, id));
    return true;
  }

  // Zero-Knowledge Proof operations
  async getZkProofs(agentId: number): Promise<ZkProof[]> {
    return db.select().from(zkProofs).where(eq(zkProofs.agentId, agentId));
  }

  async createZkProof(proof: InsertZkProof): Promise<ZkProof> {
    const [newProof] = await db
      .insert(zkProofs)
      .values(proof)
      .returning();
    return newProof;
  }

  async updateZkProof(id: number, updates: Partial<ZkProof>): Promise<ZkProof | undefined> {
    const [proof] = await db
      .update(zkProofs)
      .set(updates)
      .where(eq(zkProofs.id, id))
      .returning();
    return proof;
  }

  // Reputation System operations
  async getAgentReputation(agentId: number): Promise<ReputationScore | undefined> {
    const [score] = await db.select().from(reputationScores).where(eq(reputationScores.agentId, agentId));
    return score;
  }

  async createAgentReputation(reputation: InsertReputationScore): Promise<ReputationScore> {
    const [score] = await db
      .insert(reputationScores)
      .values(reputation)
      .returning();
    return score;
  }

  async updateAgentReputation(agentId: number, updates: Partial<ReputationScore>): Promise<ReputationScore | undefined> {
    const [score] = await db
      .update(reputationScores)
      .set(updates)
      .where(eq(reputationScores.agentId, agentId))
      .returning();
    return score;
  }

  // Autonomous Negotiation operations
  async getNegotiations(agentId: number, asInitiator: boolean = true): Promise<Negotiation[]> {
    // For initiator queries, we can use a simple equality check
    if (asInitiator) {
      return db.select().from(negotiations).where(eq(negotiations.initiatorId, agentId));
    } else {
      // For responder queries, we'll need to do a more complex check
      // Since we can't use db.raw directly, we'll get all negotiations and filter in-memory
      const allNegotiations = await db.select().from(negotiations);
      return allNegotiations.filter(negotiation => 
        negotiation.responderIds?.includes(agentId)
      );
    }
  }

  async createNegotiation(negotiation: InsertNegotiation): Promise<Negotiation> {
    const [newNegotiation] = await db
      .insert(negotiations)
      .values(negotiation)
      .returning();
    return newNegotiation;
  }

  async updateNegotiation(id: number, updates: Partial<Negotiation>): Promise<Negotiation | undefined> {
    const [negotiation] = await db
      .update(negotiations)
      .set(updates)
      .where(eq(negotiations.id, id))
      .returning();
    return negotiation;
  }
}