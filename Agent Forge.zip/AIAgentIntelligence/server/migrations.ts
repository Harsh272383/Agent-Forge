import { db } from './db';
import { users, agents, agentTemplates, agentTasks } from '@shared/schema';
import { swarms, swarmParticipants, zkProofs, reputationScores, negotiations } from '@shared/schema-extensions';

export async function createTables() {
  console.log('Creating database tables...');
  
  try {
    // Create base tables
    await db.schema
      .createTable(users)
      .createTable(agents)
      .createTable(agentTemplates)
      .createTable(agentTasks)
      .execute();
    
    console.log('Created base tables: users, agents, agentTemplates, agentTasks');
    
    // Create advanced feature tables
    await db.schema
      .createTable(swarms)
      .createTable(swarmParticipants)
      .createTable(zkProofs)
      .createTable(reputationScores)
      .createTable(negotiations)
      .execute();
    
    console.log('Created advanced feature tables: swarms, swarmParticipants, zkProofs, reputationScores, negotiations');
    
    // Add some initial data for testing
    await seedDatabase();
    
    console.log('Database tables created and seeded successfully!');
  } catch (error) {
    console.error('Error creating database tables:', error);
    throw error;
  }
}

async function seedDatabase() {
  // Insert test user
  const [testUser] = await db.insert(users).values({
    username: 'testuser',
    password: '$2a$10$JqV8YUUjfKHpMdHgVG7x5ORCVYqjx5q5Ozw0hYFxPNh.yDJHBR5/i', // "password123"
    email: 'test@example.com',
    walletAddress: '0x742d35Cc6634C0532925a3b844Bc454e4438f44e'
  }).returning();
  
  console.log('Created test user:', testUser.username);
  
  // Insert agent templates
  const templateData = [
    {
      name: "ML Training Agent",
      description: "AI agent specialized in training and tuning ML models on-chain with quantized precision.",
      agentType: "data",
      capabilities: ["model-training", "optimization", "data-analysis"],
      config: { 
        modelArchitectures: ["transformers", "neural-networks", "quantum-circuits"],
        optimizationAlgorithms: ["adaptive-learning", "quantum-annealing"]
      },
      price: 0.15,
      creator: "AgentForge",
      networks: ["ethereum", "polygon"],
      imagePath: "/images/agent-ml.svg",
      isPopular: true,
      isNew: false
    },
    {
      name: "Quantum Trading Bot",
      description: "Leverages quantum algorithms to identify trading opportunities across multiple DeFi protocols.",
      agentType: "trader",
      capabilities: ["defi-trading", "quantum-optimization", "cross-chain"],
      config: {
        supportedPairs: ["ETH/USDC", "BTC/ETH", "SOL/USDC"],
        riskLevels: ["low", "medium", "high"]
      },
      price: 0.25,
      creator: "QuantumLabs",
      networks: ["ethereum", "polygon", "arbitrum"],
      imagePath: "/images/agent-trading.svg",
      isPopular: true,
      isNew: true
    },
    {
      name: "Neural Security Monitor",
      description: "Advanced neural network-powered agent that detects and prevents security threats on DeFi positions.",
      agentType: "monitor",
      capabilities: ["anomaly-detection", "threat-prevention", "real-time-alerts"],
      config: {
        alertThreshold: "medium",
        scanFrequency: "high"
      },
      price: 0.1,
      creator: "AgentForge",
      networks: ["ethereum", "arbitrum"],
      imagePath: "/images/agent-security.svg",
      isPopular: true,
      isNew: false
    },
    {
      name: "Swarm Intelligence DAO",
      description: "Decentralized agent that coordinates multiple sub-agents to govern DAO treasuries with collective intelligence.",
      agentType: "custom",
      capabilities: ["governance", "treasury-management", "voting-optimization"],
      config: {
        governanceModels: ["liquid-democracy", "quadratic-voting"],
        treasuryStrategies: ["diversification", "yield-generation"]
      },
      price: 0.3,
      creator: "DAOmasters",
      networks: ["ethereum", "polygon", "arbitrum"],
      imagePath: "/images/agent-dao.svg",
      isPopular: false,
      isNew: true
    }
  ];
  
  for (const template of templateData) {
    await db.insert(agentTemplates).values(template);
  }
  
  console.log('Created agent templates');
  
  // Insert sample agents
  const agentData = [
    {
      userId: testUser.id,
      name: "DataCollector",
      description: "Collects and analyzes on-chain data using deep learning algorithms",
      agentType: "data",
      status: "active",
      networks: ["ethereum", "polygon"],
      walletAddress: "0x742d35Cc6634C0532925a3b844Bc454e4438f44e",
      balance: 0.25,
      config: {
        dataTypes: ["transactions", "events"],
        storageType: "ipfs",
        updateFrequency: "hourly"
      },
      performanceData: {
        dataPointsCollected: 15423,
        successRate: 99.2,
        averageResponseTime: 1.2
      }
    },
    {
      userId: testUser.id,
      name: "TradeBot",
      description: "Quantum-enhanced trading agent with neural networks for market prediction",
      agentType: "trader",
      status: "inactive",
      networks: ["ethereum", "arbitrum"],
      walletAddress: "0x843d35Cc6634C0532925a3b844Bc454e4438f213",
      balance: 0.5,
      config: {
        supportedTokens: ["ETH", "USDT", "USDC"],
        riskLevel: "medium",
        tradeSize: "auto",
        strategies: ["momentum", "mean-reversion", "quantum-arbitrage"]
      }
    },
    {
      userId: testUser.id,
      name: "SecurityMonitor",
      description: "Neural network-based security monitoring with quantum-resistant encryption",
      agentType: "monitor",
      status: "inactive",
      networks: ["ethereum"],
      walletAddress: "0x912d35Cc6634C0532925a3b844Bc454e4438f881",
      balance: 0.1,
      config: {
        alertThreshold: "high",
        monitoringInterval: "continuous",
        notificationChannels: ["webhook", "email"]
      }
    }
  ];
  
  for (const agent of agentData) {
    await db.insert(agents).values(agent);
  }
  
  console.log('Created sample agents');
  
  // Create a swarm with the agents
  const [swarm] = await db.insert(swarms).values({
    name: "Data Intelligence Network",
    description: "A collaborative swarm of agents performing complementary data tasks",
    purpose: "Aggregate and analyze multi-chain data for advanced insights",
    coordinationStrategy: "hierarchical",
    status: "active",
    creatorId: testUser.id,
    config: {
      communicationProtocol: "encrypted-p2p",
      resourceSharing: true,
      decisionAlgorithm: "weighted-consensus"
    },
    metadata: {
      foundingDate: new Date(),
      specialty: "Cross-chain data intelligence"
    }
  }).returning();
  
  console.log('Created sample swarm:', swarm.name);
  
  // Add the sample agents to the swarm
  const agentsResult = await db.select().from(agents);
  
  for (const agent of agentsResult) {
    const roles = ["worker", "specialist", "observer"];
    const randomRole = roles[Math.floor(Math.random() * roles.length)];
    
    await db.insert(swarmParticipants).values({
      swarmId: swarm.id,
      agentId: agent.id,
      role: randomRole,
      status: "active",
      contribution: Math.random() * 100,
      trustScore: 0.7 + (Math.random() * 0.3),
      specialization: agent.agentType,
      permissions: {
        canVote: true,
        canPropose: randomRole !== "observer",
        resourceAccess: "read-write"
      }
    });
  }
  
  console.log('Added agents to swarm');
}