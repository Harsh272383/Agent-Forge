import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "demo-key" });

/**
 * Generates a response for an AI agent using OpenAI
 * In the demo, we'll use basic responses if OpenAI is not available
 */
export async function generateAgentResponse(prompt: string): Promise<any> {
  try {
    // Check if we have a valid API key
    if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === "demo-key") {
      // Fall back to a demo response if no API key
      console.log("Using demo agent response (no OpenAI API key)");
      return generateDemoResponse();
    }
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an autonomous AI agent operating on blockchain networks. Generate realistic, detailed JSON responses to commands as if you were executing them on-chain."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });
    
    return JSON.parse(response.choices[0].message.content);
  } catch (error) {
    console.error("Error generating agent response:", error);
    return generateDemoResponse();
  }
}

/**
 * Generates a demo response when OpenAI is not available
 */
function generateDemoResponse(): Record<string, any> {
  // Generate a plausible blockchain transaction hash
  const generateTxHash = () => `0x${Array.from({length: 64}, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
  
  // Random chance of success/failure
  const success = Math.random() > 0.1;
  
  return {
    status: success ? "success" : "error",
    timestamp: new Date().toISOString(),
    transactionHash: success ? generateTxHash() : null,
    blockNumber: success ? Math.floor(Math.random() * 1000000) + 15000000 : null,
    gasUsed: success ? Math.floor(Math.random() * 1000000) + 50000 : null,
    result: success 
      ? { 
          executed: true, 
          outputs: ["Data successfully processed", "Operation complete"],
          processingTime: `${(Math.random() * 5 + 0.5).toFixed(2)}s`
        }
      : {
          executed: false,
          error: "Insufficient gas for transaction",
          errorCode: "OUT_OF_GAS"
        }
  };
}
