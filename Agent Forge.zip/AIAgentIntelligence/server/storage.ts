import {
  users, User, InsertUser,
  agents, Agent, InsertAgent,
  agentTemplates, AgentTemplate, InsertAgentTemplate,
  agentTasks, AgentTask, InsertAgentTask
} from "@shared/schema";

// Interface defining all storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByWallet(walletAddress: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;

  // Agent operations
  getAgent(id: number): Promise<Agent | undefined>;
  getAgentsByUser(userId: number): Promise<Agent[]>;
  getActiveAgents(): Promise<Agent[]>;
  createAgent(agent: InsertAgent): Promise<Agent>;
  updateAgent(id: number, agent: Partial<Agent>): Promise<Agent | undefined>;
  deleteAgent(id: number): Promise<boolean>;
  
  // Agent Template operations
  getAgentTemplate(id: number): Promise<AgentTemplate | undefined>;
  getAllAgentTemplates(): Promise<AgentTemplate[]>;
  getPopularAgentTemplates(limit: number): Promise<AgentTemplate[]>;
  createAgentTemplate(template: InsertAgentTemplate): Promise<AgentTemplate>;
  updateAgentTemplate(id: number, template: Partial<AgentTemplate>): Promise<AgentTemplate | undefined>;
  incrementTemplateDownloads(id: number): Promise<AgentTemplate | undefined>;
  
  // Agent Task operations
  getAgentTasks(agentId: number): Promise<AgentTask[]>;
  createAgentTask(task: InsertAgentTask): Promise<AgentTask>;
  updateAgentTask(id: number, task: Partial<AgentTask>): Promise<AgentTask | undefined>;
}

// In-memory implementation of the storage interface
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private agents: Map<number, Agent>;
  private agentTemplates: Map<number, AgentTemplate>;
  private agentTasks: Map<number, AgentTask>;
  
  private userId: number;
  private agentId: number;
  private templateId: number;
  private taskId: number;

  constructor() {
    this.users = new Map();
    this.agents = new Map();
    this.agentTemplates = new Map();
    this.agentTasks = new Map();
    
    this.userId = 1;
    this.agentId = 1;
    this.templateId = 1;
    this.taskId = 1;
    
    // Initialize with sample agent templates for the marketplace
    this.initializeSampleData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByWallet(walletAddress: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.walletAddress === walletAddress
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Agent operations
  async getAgent(id: number): Promise<Agent | undefined> {
    return this.agents.get(id);
  }

  async getAgentsByUser(userId: number): Promise<Agent[]> {
    return Array.from(this.agents.values()).filter(
      (agent) => agent.userId === userId
    );
  }

  async getActiveAgents(): Promise<Agent[]> {
    return Array.from(this.agents.values()).filter(
      (agent) => agent.status === "active"
    );
  }

  async createAgent(insertAgent: InsertAgent): Promise<Agent> {
    const id = this.agentId++;
    const now = new Date();
    const agent: Agent = {
      ...insertAgent,
      id,
      createdAt: now,
      updatedAt: now,
      lastActive: now
    };
    this.agents.set(id, agent);
    return agent;
  }

  async updateAgent(id: number, updates: Partial<Agent>): Promise<Agent | undefined> {
    const agent = this.agents.get(id);
    if (!agent) return undefined;
    
    const updatedAgent = {
      ...agent,
      ...updates,
      updatedAt: new Date()
    };
    this.agents.set(id, updatedAgent);
    return updatedAgent;
  }

  async deleteAgent(id: number): Promise<boolean> {
    return this.agents.delete(id);
  }

  // Agent Template operations
  async getAgentTemplate(id: number): Promise<AgentTemplate | undefined> {
    return this.agentTemplates.get(id);
  }

  async getAllAgentTemplates(): Promise<AgentTemplate[]> {
    return Array.from(this.agentTemplates.values());
  }

  async getPopularAgentTemplates(limit: number): Promise<AgentTemplate[]> {
    return Array.from(this.agentTemplates.values())
      .sort((a, b) => b.downloads - a.downloads)
      .slice(0, limit);
  }

  async createAgentTemplate(template: InsertAgentTemplate): Promise<AgentTemplate> {
    const id = this.templateId++;
    const now = new Date();
    const agentTemplate: AgentTemplate = {
      ...template,
      id,
      downloads: 0,
      rating: 0,
      reviewCount: 0,
      createdAt: now
    };
    this.agentTemplates.set(id, agentTemplate);
    return agentTemplate;
  }

  async updateAgentTemplate(id: number, updates: Partial<AgentTemplate>): Promise<AgentTemplate | undefined> {
    const template = this.agentTemplates.get(id);
    if (!template) return undefined;
    
    const updatedTemplate = { ...template, ...updates };
    this.agentTemplates.set(id, updatedTemplate);
    return updatedTemplate;
  }

  async incrementTemplateDownloads(id: number): Promise<AgentTemplate | undefined> {
    const template = this.agentTemplates.get(id);
    if (!template) return undefined;
    
    const updatedTemplate = {
      ...template,
      downloads: template.downloads + 1
    };
    this.agentTemplates.set(id, updatedTemplate);
    return updatedTemplate;
  }

  // Agent Task operations
  async getAgentTasks(agentId: number): Promise<AgentTask[]> {
    return Array.from(this.agentTasks.values()).filter(
      (task) => task.agentId === agentId
    );
  }

  async createAgentTask(insertTask: InsertAgentTask): Promise<AgentTask> {
    const id = this.taskId++;
    const now = new Date();
    const task: AgentTask = {
      ...insertTask,
      id,
      startTime: now,
      endTime: null
    };
    this.agentTasks.set(id, task);
    return task;
  }

  async updateAgentTask(id: number, updates: Partial<AgentTask>): Promise<AgentTask | undefined> {
    const task = this.agentTasks.get(id);
    if (!task) return undefined;
    
    const updatedTask = { ...task, ...updates };
    this.agentTasks.set(id, updatedTask);
    return updatedTask;
  }

  // Initialize some sample data for the marketplace
  private initializeSampleData() {
    // Sample Agent Templates
    const mlTemplate: InsertAgentTemplate = {
      name: "ML Training Agent",
      description: "Autonomously collects data, trains models, and optimizes ML performance without human intervention.",
      agentType: "data",
      capabilities: ["data-collection", "model-training", "optimization"],
      config: {
        requiredAPIs: ["openai", "huggingface"],
        dataStorage: "decentralized",
        modelUpdateFrequency: "daily"
      },
      price: 0.058,
      creator: "AgentForge",
      networks: ["ethereum", "polygon"],
      imagePath: "https://pixabay.com/get/g559cab0eae4f9e208dc425e847924359213705dd85aa1f0d9811b6529381263414a864af6a704f4773bea705cf3ffc9b2be0923a4bd5f05cd97ca72ae886b117_1280.jpg",
      isPopular: true,
      isNew: false
    };
    
    const tradingTemplate: InsertAgentTemplate = {
      name: "Trading Strategy Agent",
      description: "Executes custom trading strategies across multiple DEXes with real-time market analysis.",
      agentType: "trader",
      capabilities: ["market-analysis", "trade-execution", "portfolio-rebalancing"],
      config: {
        supportedDEXes: ["uniswap", "sushiswap", "pancakeswap"],
        riskLevel: "medium",
        maxSlippage: 1.5
      },
      price: 0.095,
      creator: "TradingBots Inc",
      networks: ["ethereum", "arbitrum", "polygon"],
      imagePath: "https://pixabay.com/get/g807e96de1fccdebfaef231dd896101a7118e9c6b98e0cec0ddde71035bf11691e844fc37ce1f117fe94387e57cfc16c872c7e63b2e3302d6279498c022598ae8_1280.jpg",
      isPopular: false,
      isNew: false
    };
    
    const monitorTemplate: InsertAgentTemplate = {
      name: "Multi-Chain Monitor",
      description: "Monitors transactions across chains, detects anomalies, and sends alerts to defined channels.",
      agentType: "monitor",
      capabilities: ["cross-chain-monitoring", "anomaly-detection", "alert-system"],
      config: {
        monitoringInterval: "5m",
        alertChannels: ["email", "telegram", "discord"],
        thresholdSettings: { transactions: 100, gas: 500 }
      },
      price: 0.075,
      creator: "ChainGuard",
      networks: ["ethereum", "polygon", "arbitrum", "optimism"],
      imagePath: "https://images.unsplash.com/photo-1639762681057-408e52192e55?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300",
      isPopular: false,
      isNew: false
    };
    
    const daoTemplate: InsertAgentTemplate = {
      name: "DAO Contributor Agent",
      description: "Handles DAO governance tasks, proposal analysis, and voting recommendations with audit trail.",
      agentType: "custom",
      capabilities: ["governance", "proposal-analysis", "voting"],
      config: {
        supportedDAOs: ["aave", "maker", "compound"],
        analysisDepth: "comprehensive",
        votingStrategy: "optimistic"
      },
      price: 0.065,
      creator: "DAOmaster",
      networks: ["ethereum"],
      imagePath: "https://pixabay.com/get/g8d59eaebd509c13db70193e831759732957becf2027b0ae44e7cfe1a61505ee592c8a9ac67e191f4856a9ee13d342fd3b94bd5536f27aa76eecc28cf5072ee83_1280.jpg",
      isPopular: false,
      isNew: true
    };

    // Add templates to storage
    this.createAgentTemplate(mlTemplate);
    this.createAgentTemplate(tradingTemplate);
    this.createAgentTemplate(monitorTemplate);
    this.createAgentTemplate(daoTemplate);
    
    // Sample active agents
    const sampleAgents: InsertAgent[] = [
      {
        userId: 1,
        name: "DataCollector",
        description: "Collects on-chain data and stores it for analysis",
        agentType: "data",
        status: "active",
        networks: ["ethereum"],
        walletAddress: "0x7f...2e8b",
        balance: 0.085,
        config: {
          dataTypes: ["transactions", "events"],
          storageType: "ipfs",
          updateFrequency: "hourly"
        },
        metadata: {
          version: "1.0.0",
          creator: "AgentForge"
        },
        performanceData: {
          tasksCompleted: 24,
          tasksTotal: 30,
          uptime: "6d 12h"
        },
        isPublic: false
      },
      {
        userId: 1,
        name: "TradeBot",
        description: "Executes trades on decentralized exchanges",
        agentType: "trader",
        status: "active",
        networks: ["ethereum", "polygon"],
        walletAddress: "0x3a...9f7c",
        balance: 0.240,
        config: {
          tokens: ["ETH", "USDC", "WBTC"],
          exchanges: ["uniswap", "sushiswap"],
          strategy: "arbitrage"
        },
        metadata: {
          version: "2.1.0",
          creator: "TradeBot Inc"
        },
        performanceData: {
          successRate: 78,
          tradesExecuted: 42,
          uptime: "3d 4h"
        },
        isPublic: false
      },
      {
        userId: 1,
        name: "SecurityMonitor",
        description: "Monitors for suspicious activity and generates alerts",
        agentType: "monitor",
        status: "active",
        networks: ["ethereum", "arbitrum"],
        walletAddress: "0xb1...4e2a",
        balance: 0.056,
        config: {
          alertThresholds: {
            largeTransfers: 10,
            suspiciousPatterns: "high"
          },
          notificationChannels: ["email", "discord"]
        },
        metadata: {
          version: "1.2.0",
          creator: "SecuritySystems LLC"
        },
        performanceData: {
          alertsGenerated: 12,
          falsePositives: 2,
          uptime: "14d 7h"
        },
        isPublic: false
      }
    ];

    // Add sample agents
    for (const agent of sampleAgents) {
      this.createAgent(agent);
    }
  }
}

import { DatabaseStorage } from "./storage-db";

// Choose which storage implementation to use
export const storage = new DatabaseStorage();
