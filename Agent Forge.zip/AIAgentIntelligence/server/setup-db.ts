import { db } from './db';
import { sql } from 'drizzle-orm';

/**
 * Creates all required tables in the database
 */
export async function setupDatabase() {
  console.log('Setting up database tables...');
  
  try {
    // First check if tables already exist
    const tableCheck = await db.execute(sql`
      SELECT EXISTS (
        SELECT FROM pg_tables 
        WHERE schemaname = 'public' 
        AND tablename = 'users'
      );
    `);
    
    if (tableCheck.rows[0].exists) {
      console.log('Database tables already exist, skipping setup');
      return;
    }
    
    console.log('Creating tables...');
    
    // Create users table
    await db.execute(sql`
      CREATE TABLE users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        wallet_address TEXT UNIQUE,
        email TEXT,
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);
    
    // Create agents table
    await db.execute(sql`
      CREATE TABLE agents (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        agent_type TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'inactive',
        networks TEXT[] NOT NULL,
        wallet_address TEXT,
        balance REAL DEFAULT 0,
        config JSONB,
        metadata JSONB,
        performance_data JSONB,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW(),
        last_active TIMESTAMP,
        is_public BOOLEAN DEFAULT FALSE
      );
    `);
    
    // Create agent_templates table
    await db.execute(sql`
      CREATE TABLE agent_templates (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT NOT NULL,
        agent_type TEXT NOT NULL,
        capabilities TEXT[],
        config JSONB,
        price REAL,
        creator TEXT,
        downloads INTEGER DEFAULT 0,
        rating REAL DEFAULT 0,
        review_count INTEGER DEFAULT 0,
        networks TEXT[],
        image_path TEXT,
        is_popular BOOLEAN DEFAULT FALSE,
        is_new BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);
    
    // Create agent_tasks table
    await db.execute(sql`
      CREATE TABLE agent_tasks (
        id SERIAL PRIMARY KEY,
        agent_id INTEGER NOT NULL,
        task_type TEXT NOT NULL,
        status TEXT NOT NULL,
        input JSONB,
        output JSONB,
        transaction_hash TEXT,
        network TEXT,
        start_time TIMESTAMP DEFAULT NOW(),
        end_time TIMESTAMP,
        error TEXT
      );
    `);
    
    // Create swarms table
    await db.execute(sql`
      CREATE TABLE swarms (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        purpose TEXT NOT NULL,
        coordination_strategy TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'inactive',
        participant_count INTEGER DEFAULT 0,
        config JSONB,
        metadata JSONB,
        creator_id INTEGER NOT NULL,
        performance_metrics JSONB,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW(),
        last_active TIMESTAMP
      );
    `);
    
    // Create swarm_participants table
    await db.execute(sql`
      CREATE TABLE swarm_participants (
        id SERIAL PRIMARY KEY,
        swarm_id INTEGER NOT NULL,
        agent_id INTEGER NOT NULL,
        role TEXT NOT NULL,
        join_date TIMESTAMP DEFAULT NOW(),
        leave_date TIMESTAMP,
        status TEXT NOT NULL DEFAULT 'active',
        contribution REAL DEFAULT 0,
        trust_score REAL DEFAULT 0.75,
        earnings REAL DEFAULT 0,
        specialization TEXT,
        permissions JSONB
      );
    `);
    
    // Create zk_proofs table
    await db.execute(sql`
      CREATE TABLE zk_proofs (
        id SERIAL PRIMARY KEY,
        agent_id INTEGER NOT NULL,
        proof_type TEXT NOT NULL,
        proof_hash TEXT NOT NULL,
        verification_contract TEXT,
        network TEXT NOT NULL,
        status TEXT NOT NULL,
        data JSONB,
        metadata JSONB,
        transaction_hash TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        verified_at TIMESTAMP
      );
    `);
    
    // Create reputation_scores table
    await db.execute(sql`
      CREATE TABLE reputation_scores (
        id SERIAL PRIMARY KEY,
        agent_id INTEGER NOT NULL,
        overall_score REAL DEFAULT 0,
        reliability_score REAL DEFAULT 0,
        performance_score REAL DEFAULT 0,
        security_score REAL DEFAULT 0,
        innovation_score REAL DEFAULT 0,
        compliance_score REAL DEFAULT 0,
        community_score REAL DEFAULT 0,
        endorsements INTEGER DEFAULT 0,
        critical_votes INTEGER DEFAULT 0,
        attestations JSONB,
        last_updated TIMESTAMP DEFAULT NOW(),
        history JSONB
      );
    `);
    
    // Create negotiations table
    await db.execute(sql`
      CREATE TABLE negotiations (
        id SERIAL PRIMARY KEY,
        initiator_id INTEGER NOT NULL,
        responder_ids INTEGER[] DEFAULT '{}',
        status TEXT NOT NULL,
        type TEXT NOT NULL,
        objective TEXT NOT NULL,
        terms JSONB,
        counter_offers JSONB,
        final_agreement JSONB,
        contract_address TEXT,
        started_at TIMESTAMP DEFAULT NOW(),
        completed_at TIMESTAMP,
        settlement_proof TEXT,
        dispute_resolution JSONB
      );
    `);
    
    console.log('Creating sample data...');
    await seedSampleData();
    
    console.log('Database setup completed successfully!');
  } catch (error) {
    console.error('Error setting up database:', error);
    throw error;
  }
}

async function seedSampleData() {
  // Insert test user
  await db.execute(sql`
    INSERT INTO users (username, password, email, wallet_address)
    VALUES ('testuser', '$2a$10$JqV8YUUjfKHpMdHgVG7x5ORCVYqjx5q5Ozw0hYFxPNh.yDJHBR5/i', 'test@example.com', '0x742d35Cc6634C0532925a3b844Bc454e4438f44e')
  `);
  
  const userId = await db.execute(sql`SELECT id FROM users WHERE username = 'testuser'`);
  const testUserId = userId.rows[0].id;
  
  console.log('Created test user: testuser');
  
  // Insert agent templates
  const templateData = [
    {
      name: "ML Training Agent",
      description: "AI agent specialized in training and tuning ML models on-chain with quantized precision.",
      agentType: "data",
      capabilities: ["model-training", "optimization", "data-analysis"],
      config: { 
        modelArchitectures: ["transformers", "neural-networks", "quantum-circuits"],
        optimizationAlgorithms: ["adaptive-learning", "quantum-annealing"]
      },
      price: 0.15,
      creator: "AgentForge",
      networks: ["ethereum", "polygon"],
      imagePath: "/images/agent-ml.svg",
      isPopular: true,
      isNew: false
    },
    {
      name: "Quantum Trading Bot",
      description: "Leverages quantum algorithms to identify trading opportunities across multiple DeFi protocols.",
      agentType: "trader",
      capabilities: ["defi-trading", "quantum-optimization", "cross-chain"],
      config: {
        supportedPairs: ["ETH/USDC", "BTC/ETH", "SOL/USDC"],
        riskLevels: ["low", "medium", "high"]
      },
      price: 0.25,
      creator: "QuantumLabs",
      networks: ["ethereum", "polygon", "arbitrum"],
      imagePath: "/images/agent-trading.svg",
      isPopular: true,
      isNew: true
    },
    {
      name: "Neural Security Monitor",
      description: "Advanced neural network-powered agent that detects and prevents security threats on DeFi positions.",
      agentType: "monitor",
      capabilities: ["anomaly-detection", "threat-prevention", "real-time-alerts"],
      config: {
        alertThreshold: "medium",
        scanFrequency: "high"
      },
      price: 0.1,
      creator: "AgentForge",
      networks: ["ethereum", "arbitrum"],
      imagePath: "/images/agent-security.svg",
      isPopular: true,
      isNew: false
    },
    {
      name: "Swarm Intelligence DAO",
      description: "Decentralized agent that coordinates multiple sub-agents to govern DAO treasuries with collective intelligence.",
      agentType: "custom",
      capabilities: ["governance", "treasury-management", "voting-optimization"],
      config: {
        governanceModels: ["liquid-democracy", "quadratic-voting"],
        treasuryStrategies: ["diversification", "yield-generation"]
      },
      price: 0.3,
      creator: "DAOmasters",
      networks: ["ethereum", "polygon", "arbitrum"],
      imagePath: "/images/agent-dao.svg",
      isPopular: false,
      isNew: true
    }
  ];
  
  for (const template of templateData) {
    await db.execute(sql`
      INSERT INTO agent_templates (
        name, description, agent_type, capabilities, config, 
        price, creator, networks, image_path, is_popular, is_new
      )
      VALUES (
        ${template.name}, 
        ${template.description}, 
        ${template.agentType}, 
        ARRAY[${template.capabilities.map(c => `'${c}'`).join(', ')}]::text[], 
        ${JSON.stringify(template.config)}, 
        ${template.price}, 
        ${template.creator}, 
        ARRAY[${template.networks.map(n => `'${n}'`).join(', ')}]::text[], 
        ${template.imagePath}, 
        ${template.isPopular}, 
        ${template.isNew}
      )
    `);
  }
  
  console.log('Created agent templates');
  
  // Insert sample agents
  const agentData = [
    {
      userId: testUserId,
      name: "DataCollector",
      description: "Collects and analyzes on-chain data using deep learning algorithms",
      agentType: "data",
      status: "active",
      networks: ["ethereum", "polygon"],
      walletAddress: "0x742d35Cc6634C0532925a3b844Bc454e4438f44e",
      balance: 0.25,
      config: {
        dataTypes: ["transactions", "events"],
        storageType: "ipfs",
        updateFrequency: "hourly"
      },
      performanceData: {
        dataPointsCollected: 15423,
        successRate: 99.2,
        averageResponseTime: 1.2
      }
    },
    {
      userId: testUserId,
      name: "TradeBot",
      description: "Quantum-enhanced trading agent with neural networks for market prediction",
      agentType: "trader",
      status: "inactive",
      networks: ["ethereum", "arbitrum"],
      walletAddress: "0x843d35Cc6634C0532925a3b844Bc454e4438f213",
      balance: 0.5,
      config: {
        supportedTokens: ["ETH", "USDT", "USDC"],
        riskLevel: "medium",
        tradeSize: "auto",
        strategies: ["momentum", "mean-reversion", "quantum-arbitrage"]
      }
    },
    {
      userId: testUserId,
      name: "SecurityMonitor",
      description: "Neural network-based security monitoring with quantum-resistant encryption",
      agentType: "monitor",
      status: "inactive",
      networks: ["ethereum"],
      walletAddress: "0x912d35Cc6634C0532925a3b844Bc454e4438f881",
      balance: 0.1,
      config: {
        alertThreshold: "high",
        monitoringInterval: "continuous",
        notificationChannels: ["webhook", "email"]
      }
    }
  ];
  
  for (const agent of agentData) {
    await db.execute(sql`
      INSERT INTO agents (
        user_id, name, description, agent_type, status, networks, 
        wallet_address, balance, config, performance_data
      )
      VALUES (
        ${agent.userId}, 
        ${agent.name}, 
        ${agent.description}, 
        ${agent.agentType}, 
        ${agent.status}, 
        ARRAY[${agent.networks.map(n => `'${n}'`).join(', ')}]::text[], 
        ${agent.walletAddress}, 
        ${agent.balance}, 
        ${JSON.stringify(agent.config)}, 
        ${agent.performanceData ? JSON.stringify(agent.performanceData) : null}
      )
    `);
  }
  
  console.log('Created sample agents');
  
  // Create a swarm with the agents
  await db.execute(sql`
    INSERT INTO swarms (
      name, description, purpose, coordination_strategy, status, creator_id,
      config, metadata
    )
    VALUES (
      'Data Intelligence Network',
      'A collaborative swarm of agents performing complementary data tasks',
      'Aggregate and analyze multi-chain data for advanced insights',
      'hierarchical',
      'active',
      ${testUserId},
      ${JSON.stringify({
        communicationProtocol: "encrypted-p2p",
        resourceSharing: true,
        decisionAlgorithm: "weighted-consensus"
      })},
      ${JSON.stringify({
        foundingDate: new Date(),
        specialty: "Cross-chain data intelligence"
      })}
    )
  `);
  
  const swarmId = await db.execute(sql`SELECT id FROM swarms WHERE name = 'Data Intelligence Network'`);
  const dataSwarmId = swarmId.rows[0].id;
  
  console.log('Created sample swarm: Data Intelligence Network');
  
  // Add the sample agents to the swarm
  const agentsResult = await db.execute(sql`SELECT id, agent_type FROM agents`);
  
  for (const agent of agentsResult.rows) {
    const roles = ["worker", "specialist", "observer"];
    const randomRole = roles[Math.floor(Math.random() * roles.length)];
    
    await db.execute(sql`
      INSERT INTO swarm_participants (
        swarm_id, agent_id, role, status, contribution, trust_score,
        specialization, permissions
      )
      VALUES (
        ${dataSwarmId},
        ${agent.id},
        ${randomRole},
        'active',
        ${Math.random() * 100},
        ${0.7 + (Math.random() * 0.3)},
        ${agent.agent_type},
        ${JSON.stringify({
          canVote: true,
          canPropose: randomRole !== "observer",
          resourceAccess: "read-write"
        })}
      )
    `);
  }
  
  console.log('Added agents to swarm');
}