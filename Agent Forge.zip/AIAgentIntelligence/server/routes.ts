import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import "./types"; // Import extended types
import { z } from "zod";
import { insertAgentSchema, insertAgentTaskSchema, insertAgentTemplateSchema } from "@shared/schema";
import { createAIAgent, runAgentCommand } from "./services/aiAgent";

export async function registerRoutes(app: Express): Promise<Server> {
  const apiRouter = express.Router();
  
  // Middleware to simulate auth for demo purposes
  // In a real app, we'd have proper authentication
  apiRouter.use((req, res, next) => {
    // For demo, we'll set a default user ID (would come from auth in real app)
    req.userId = 1;
    next();
  });
  
  // ============= Agent Templates (Marketplace) API =============
  
  // Get all templates
  apiRouter.get("/agent-templates", async (req: Request, res: Response) => {
    try {
      const templates = await storage.getAllAgentTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error fetching agent templates:", error);
      res.status(500).json({ message: "Failed to fetch agent templates" });
    }
  });
  
  // Get popular templates
  apiRouter.get("/agent-templates/popular", async (req: Request, res: Response) => {
    try {
      const limit = parseInt(req.query.limit as string) || 4;
      const templates = await storage.getPopularAgentTemplates(limit);
      res.json(templates);
    } catch (error) {
      console.error("Error fetching popular templates:", error);
      res.status(500).json({ message: "Failed to fetch popular templates" });
    }
  });
  
  // Get template by id
  apiRouter.get("/agent-templates/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid template ID" });
      }
      
      const template = await storage.getAgentTemplate(id);
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      res.json(template);
    } catch (error) {
      console.error("Error fetching template:", error);
      res.status(500).json({ message: "Failed to fetch template" });
    }
  });
  
  // Create a new template from an agent
  apiRouter.post("/agent-templates", async (req: Request, res: Response) => {
    try {
      const templateData = insertAgentTemplateSchema.parse(req.body);
      const template = await storage.createAgentTemplate(templateData);
      res.status(201).json(template);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid template data", errors: error.errors });
      }
      console.error("Error creating template:", error);
      res.status(500).json({ message: "Failed to create template" });
    }
  });
  
  // Deploy a template (download/increment counter)
  apiRouter.post("/agent-templates/:id/deploy", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid template ID" });
      }
      
      const template = await storage.getAgentTemplate(id);
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      // Update download count
      await storage.incrementTemplateDownloads(id);
      
      // Create an agent from the template
      const userId = req.userId || 1; // In a real app, this would come from auth
      
      const agentData = {
        userId,
        name: template.name,
        description: template.description,
        agentType: template.agentType,
        status: "inactive", // Start as inactive until user configures and activates
        networks: template.networks || ["ethereum"],
        config: template.config || {},
        metadata: {
          templateId: template.id,
          version: "1.0.0",
        },
        isPublic: false,
      };
      
      const agent = await storage.createAgent(agentData);
      res.status(201).json(agent);
    } catch (error) {
      console.error("Error deploying template:", error);
      res.status(500).json({ message: "Failed to deploy template" });
    }
  });
  
  // ============= Agents API =============
  
  // Get all active agents
  apiRouter.get("/agents/active", async (req: Request, res: Response) => {
    try {
      const agents = await storage.getActiveAgents();
      res.json(agents);
    } catch (error) {
      console.error("Error fetching active agents:", error);
      res.status(500).json({ message: "Failed to fetch active agents" });
    }
  });
  
  // Get user's agents
  apiRouter.get("/agents", async (req: Request, res: Response) => {
    try {
      const userId = req.userId || 1; // In a real app, this would come from auth
      const agents = await storage.getAgentsByUser(userId);
      res.json(agents);
    } catch (error) {
      console.error("Error fetching user agents:", error);
      res.status(500).json({ message: "Failed to fetch user agents" });
    }
  });
  
  // Get agent by id
  apiRouter.get("/agents/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid agent ID" });
      }
      
      const agent = await storage.getAgent(id);
      if (!agent) {
        return res.status(404).json({ message: "Agent not found" });
      }
      
      // Check ownership in a real app
      // if (agent.userId !== req.userId) {
      //   return res.status(403).json({ message: "Not authorized to access this agent" });
      // }
      
      res.json(agent);
    } catch (error) {
      console.error("Error fetching agent:", error);
      res.status(500).json({ message: "Failed to fetch agent" });
    }
  });
  
  // Create a new agent
  apiRouter.post("/agents", async (req: Request, res: Response) => {
    try {
      const userId = req.userId || 1; // In a real app, this would come from auth
      
      // Validate agent data
      const agentData = insertAgentSchema.parse({
        ...req.body,
        userId
      });
      
      // Create the agent
      const agent = await storage.createAgent(agentData);
      
      // Initialize AI agent if needed
      if (req.body.initialize) {
        try {
          const aiAgent = await createAIAgent(agent);
          // In a real app, we'd store the AI agent reference
        } catch (aiError) {
          console.error("Error initializing AI agent:", aiError);
          // Continue anyway, the agent is created but initialization failed
        }
      }
      
      res.status(201).json(agent);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid agent data", errors: error.errors });
      }
      console.error("Error creating agent:", error);
      res.status(500).json({ message: "Failed to create agent" });
    }
  });
  
  // Update an agent
  apiRouter.patch("/agents/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid agent ID" });
      }
      
      const agent = await storage.getAgent(id);
      if (!agent) {
        return res.status(404).json({ message: "Agent not found" });
      }
      
      // Check ownership in a real app
      // if (agent.userId !== req.userId) {
      //   return res.status(403).json({ message: "Not authorized to update this agent" });
      // }
      
      // Update the agent
      const updatedAgent = await storage.updateAgent(id, req.body);
      res.json(updatedAgent);
    } catch (error) {
      console.error("Error updating agent:", error);
      res.status(500).json({ message: "Failed to update agent" });
    }
  });
  
  // Delete an agent
  apiRouter.delete("/agents/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid agent ID" });
      }
      
      const agent = await storage.getAgent(id);
      if (!agent) {
        return res.status(404).json({ message: "Agent not found" });
      }
      
      // Check ownership in a real app
      // if (agent.userId !== req.userId) {
      //   return res.status(403).json({ message: "Not authorized to delete this agent" });
      // }
      
      const success = await storage.deleteAgent(id);
      if (success) {
        res.status(204).end();
      } else {
        res.status(500).json({ message: "Failed to delete agent" });
      }
    } catch (error) {
      console.error("Error deleting agent:", error);
      res.status(500).json({ message: "Failed to delete agent" });
    }
  });
  
  // Start/stop agent
  apiRouter.post("/agents/:id/toggle", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid agent ID" });
      }
      
      const agent = await storage.getAgent(id);
      if (!agent) {
        return res.status(404).json({ message: "Agent not found" });
      }
      
      // Check ownership in a real app
      // if (agent.userId !== req.userId) {
      //   return res.status(403).json({ message: "Not authorized to control this agent" });
      // }
      
      const newStatus = agent.status === "active" ? "inactive" : "active";
      const updatedAgent = await storage.updateAgent(id, { 
        status: newStatus,
        lastActive: newStatus === "active" ? new Date() : agent.lastActive
      });
      
      res.json(updatedAgent);
    } catch (error) {
      console.error("Error toggling agent:", error);
      res.status(500).json({ message: "Failed to toggle agent" });
    }
  });
  
  // ============= Agent Tasks API =============
  
  // Get tasks for an agent
  apiRouter.get("/agents/:id/tasks", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid agent ID" });
      }
      
      const agent = await storage.getAgent(id);
      if (!agent) {
        return res.status(404).json({ message: "Agent not found" });
      }
      
      // Check ownership in a real app
      // if (agent.userId !== req.userId) {
      //   return res.status(403).json({ message: "Not authorized to access tasks for this agent" });
      // }
      
      const tasks = await storage.getAgentTasks(id);
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching agent tasks:", error);
      res.status(500).json({ message: "Failed to fetch agent tasks" });
    }
  });
  
  // Execute agent command/task
  apiRouter.post("/agents/:id/execute", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid agent ID" });
      }
      
      const agent = await storage.getAgent(id);
      if (!agent) {
        return res.status(404).json({ message: "Agent not found" });
      }
      
      // Check ownership in a real app
      // if (agent.userId !== req.userId) {
      //   return res.status(403).json({ message: "Not authorized to execute commands for this agent" });
      // }
      
      if (agent.status !== "active") {
        return res.status(400).json({ message: "Agent is not active" });
      }
      
      // Create a task entry
      const taskData = insertAgentTaskSchema.parse({
        agentId: agent.id,
        taskType: req.body.command || "custom",
        status: "pending",
        input: req.body
      });
      
      const task = await storage.createAgentTask(taskData);
      
      // Execute the command (in a real app, this would be more sophisticated)
      try {
        const result = await runAgentCommand(agent, req.body.command, req.body.params);
        
        // Update the task with the result
        const updatedTask = await storage.updateAgentTask(task.id, {
          status: "completed",
          output: result,
          endTime: new Date()
        });
        
        res.json(updatedTask);
      } catch (execError: any) {
        // Update task as failed
        const updatedTask = await storage.updateAgentTask(task.id, {
          status: "failed",
          error: execError.message || "Unknown execution error",
          endTime: new Date()
        });
        
        res.status(500).json(updatedTask);
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors: error.errors });
      }
      console.error("Error executing agent command:", error);
      res.status(500).json({ message: "Failed to execute agent command" });
    }
  });

  // Add About endpoint
  apiRouter.get("/about", async (req: Request, res: Response) => {
    res.json({
      developer: "Harsh Patil",
      role: "Developer and Data Scientist",
      project: "AI Agents Berlin Hackathon 2025",
      technologies: [
        "AI/ML Integration",
        "Deep Learning",
        "Quantum Computing Algorithms",
        "Real-time Communication",
        "Multi-agent Swarm Coordination",
        "Zero-knowledge Proof Verification",
        "On-chain Reputation System",
        "Autonomous Negotiation"
      ],
      version: "1.0.0"
    });
  });

  // Mount API routes with prefix
  app.use("/api", apiRouter);
  
  const httpServer = createServer(app);

  // Set up WebSocket server for real-time communication
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Connected clients
  const clients = new Map<WebSocket, { id: string, agentIds: number[] }>();
  
  wss.on('connection', (ws) => {
    // Generate a unique client ID
    const clientId = Date.now().toString();
    clients.set(ws, { id: clientId, agentIds: [] });
    
    console.log(`New WebSocket client connected: ${clientId}`);
    
    // Send initial welcome message
    ws.send(JSON.stringify({
      type: 'connection',
      message: 'Connected to AI Agent Platform WebSocket server',
      clientId
    }));
    
    // Handle messages from clients
    ws.on('message', async (messageData) => {
      try {
        const message = JSON.parse(messageData.toString());
        
        // Handle subscription to agent updates
        if (message.type === 'subscribe' && message.agentId) {
          const agentId = parseInt(message.agentId);
          const clientInfo = clients.get(ws);
          
          if (clientInfo && !clientInfo.agentIds.includes(agentId)) {
            clientInfo.agentIds.push(agentId);
            clients.set(ws, clientInfo);
            
            console.log(`Client ${clientInfo.id} subscribed to agent ${agentId}`);
            
            // Confirm subscription
            ws.send(JSON.stringify({
              type: 'subscribed',
              agentId,
              message: `Subscribed to updates for agent ${agentId}`
            }));
          }
        }
        
        // Handle agent to agent communication
        if (message.type === 'agent-message' && message.targetAgentId) {
          const targetAgentId = parseInt(message.targetAgentId);
          
          // Broadcast to all clients subscribed to this agent
          broadcastToAgent(targetAgentId, {
            type: 'agent-communication',
            sourceAgentId: message.sourceAgentId,
            targetAgentId,
            content: message.content,
            timestamp: new Date().toISOString()
          });
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
        ws.send(JSON.stringify({
          type: 'error',
          message: 'Failed to process message'
        }));
      }
    });
    
    // Handle client disconnection
    ws.on('close', () => {
      const clientInfo = clients.get(ws);
      console.log(`WebSocket client disconnected: ${clientInfo?.id}`);
      clients.delete(ws);
    });
  });
  
  // Function to broadcast a message to all clients subscribed to an agent
  function broadcastToAgent(agentId: number, message: any) {
    clients.forEach((clientInfo, client) => {
      if (clientInfo.agentIds.includes(agentId) && client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
  }
  
  // Function to broadcast agent status updates
  // Make available to other modules
  const broadcastAgentUpdate = function(agentId: number, update: any) {
    broadcastToAgent(agentId, {
      type: 'agent-update',
      agentId,
      update,
      timestamp: new Date().toISOString()
    });
  };
  
  // Export the broadcast function for other modules to use
  (global as any).broadcastAgentUpdate = broadcastAgentUpdate;
  
  return httpServer;
}
