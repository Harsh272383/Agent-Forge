import { pgTable, text, serial, integer, boolean, jsonb, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Basic user account
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  walletAddress: text("wallet_address").unique(),
  email: text("email"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Agent table definition
export const agents = pgTable("agents", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(), // Creator of the agent
  name: text("name").notNull(),
  description: text("description"),
  agentType: text("agent_type").notNull(), // "monitor", "trader", "data", "custom"
  status: text("status").notNull().default("inactive"), // "active", "inactive", "error"
  networks: text("networks").array().notNull(), // ["ethereum", "polygon", etc.]
  walletAddress: text("wallet_address"),
  balance: real("balance").default(0),
  config: jsonb("config"), // Configuration/capabilities
  metadata: jsonb("metadata"), // Additional metadata
  performanceData: jsonb("performance_data"), // Performance metrics
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  lastActive: timestamp("last_active"),
  isPublic: boolean("is_public").default(false),
});

// Agent Templates for Marketplace
export const agentTemplates = pgTable("agent_templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  agentType: text("agent_type").notNull(),
  capabilities: text("capabilities").array(),
  config: jsonb("config"), // Base configuration
  price: real("price"), // Price in ETH
  creator: text("creator"),
  downloads: integer("downloads").default(0),
  rating: real("rating").default(0),
  reviewCount: integer("review_count").default(0),
  networks: text("networks").array(), // Compatible networks
  imagePath: text("image_path"),
  isPopular: boolean("is_popular").default(false),
  isNew: boolean("is_new").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Agent Tasks (work history)
export const agentTasks = pgTable("agent_tasks", {
  id: serial("id").primaryKey(),
  agentId: integer("agent_id").notNull(),
  taskType: text("task_type").notNull(), // Type of task performed
  status: text("status").notNull(), // "pending", "completed", "failed"
  input: jsonb("input"), // Input data
  output: jsonb("output"), // Output/result
  transactionHash: text("transaction_hash"), // For on-chain tasks
  network: text("network"), // Which network this task ran on
  startTime: timestamp("start_time").defaultNow(),
  endTime: timestamp("end_time"),
  error: text("error"), // Error message if failed
});

// Define Zod schemas for insertion operations
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertAgentSchema = createInsertSchema(agents).omit({ id: true, createdAt: true, updatedAt: true, lastActive: true });
export const insertAgentTemplateSchema = createInsertSchema(agentTemplates).omit({ id: true, createdAt: true, downloads: true, rating: true, reviewCount: true });
export const insertAgentTaskSchema = createInsertSchema(agentTasks).omit({ id: true, startTime: true, endTime: true });

// Define types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Agent = typeof agents.$inferSelect;
export type InsertAgent = z.infer<typeof insertAgentSchema>;

export type AgentTemplate = typeof agentTemplates.$inferSelect;
export type InsertAgentTemplate = z.infer<typeof insertAgentTemplateSchema>;

export type AgentTask = typeof agentTasks.$inferSelect;
export type InsertAgentTask = z.infer<typeof insertAgentTaskSchema>;
