import { pgTable, text, serial, integer, boolean, jsonb, timestamp, real, foreignKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { agents } from "./schema";

// Multi-Agent Swarm Coordination System
export const swarms = pgTable("swarms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  purpose: text("purpose").notNull(),
  coordinationStrategy: text("coordination_strategy").notNull(), // "consensus", "hierarchical", "market", "autonomous"
  status: text("status").notNull().default("inactive"), // "active", "inactive", "coordinating"
  participantCount: integer("participant_count").default(0),
  config: jsonb("config"), // Swarm configuration parameters
  metadata: jsonb("metadata"), // Additional metadata
  creatorId: integer("creator_id").notNull(), // User who created the swarm
  performanceMetrics: jsonb("performance_metrics"), // Collective intelligence metrics
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  lastActive: timestamp("last_active"),
});

// Swarm Participants Table (Agents in a swarm)
export const swarmParticipants = pgTable("swarm_participants", {
  id: serial("id").primaryKey(),
  swarmId: integer("swarm_id").notNull().references(() => swarms.id),
  agentId: integer("agent_id").notNull().references(() => agents.id),
  role: text("role").notNull(), // "leader", "worker", "observer", "specialist"
  joinDate: timestamp("join_date").defaultNow(),
  leaveDate: timestamp("leave_date"),
  status: text("status").notNull().default("active"), // "active", "inactive", "busy"
  contribution: real("contribution").default(0), // Contribution score
  trustScore: real("trust_score").default(0.75), // Trust within swarm
  earnings: real("earnings").default(0), // Earnings from participation
  specialization: text("specialization"), // What this agent specializes in
  permissions: jsonb("permissions"), // What operations this agent can perform
});

// Zero-Knowledge Proof Verification System
export const zkProofs = pgTable("zk_proofs", {
  id: serial("id").primaryKey(),
  agentId: integer("agent_id").notNull().references(() => agents.id),
  proofType: text("proof_type").notNull(), // "identity", "action", "state", "computation"
  proofHash: text("proof_hash").notNull(), // Hash of the ZK proof
  verificationContract: text("verification_contract"), // On-chain contract used for verification
  network: text("network").notNull(), // Blockchain network
  status: text("status").notNull(), // "verified", "pending", "rejected"
  data: jsonb("data"), // Public inputs or other data
  metadata: jsonb("metadata"), // Additional proof metadata
  transactionHash: text("transaction_hash"), // Hash of verification transaction
  createdAt: timestamp("created_at").defaultNow(),
  verifiedAt: timestamp("verified_at"),
});

// On-Chain Agent Reputation System
export const reputationScores = pgTable("reputation_scores", {
  id: serial("id").primaryKey(),
  agentId: integer("agent_id").notNull().references(() => agents.id),
  overallScore: real("overall_score").default(0), // 0-100 reputation score
  reliabilityScore: real("reliability_score").default(0), // Task completion reliability
  performanceScore: real("performance_score").default(0), // Performance quality
  securityScore: real("security_score").default(0), // Security practices
  innovationScore: real("innovation_score").default(0), // Innovative solutions
  complianceScore: real("compliance_score").default(0), // Regulatory compliance
  communityScore: real("community_score").default(0), // Community contribution
  endorsements: integer("endorsements").default(0), // Number of endorsements
  criticalVotes: integer("critical_votes").default(0), // Number of critical votes
  attestations: jsonb("attestations"), // On-chain attestations
  lastUpdated: timestamp("last_updated").defaultNow(),
  history: jsonb("history"), // Historical reputation data
});

// Autonomous Negotiation & Agreement System
export const negotiations = pgTable("negotiations", {
  id: serial("id").primaryKey(),
  initiatorId: integer("initiator_id").notNull().references(() => agents.id),
  responderIds: integer("responder_ids").array(), // Multiple responders possible
  status: text("status").notNull(), // "proposed", "negotiating", "agreed", "rejected", "completed"
  type: text("type").notNull(), // "service", "data", "resource", "collaboration"
  objective: text("objective").notNull(), // What is being negotiated
  terms: jsonb("terms"), // Terms of the agreement
  counterOffers: jsonb("counter_offers"), // History of counteroffers
  finalAgreement: jsonb("final_agreement"), // The final agreed terms
  contractAddress: text("contract_address"), // On-chain smart contract 
  startedAt: timestamp("started_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  settlementProof: text("settlement_proof"), // Proof of settlement
  disputeResolution: jsonb("dispute_resolution"), // Dispute resolution mechanism
});

// Define insertion schemas
export const insertSwarmSchema = createInsertSchema(swarms).omit({ id: true, createdAt: true, updatedAt: true, lastActive: true });
export const insertSwarmParticipantSchema = createInsertSchema(swarmParticipants).omit({ id: true, joinDate: true, leaveDate: true });
export const insertZkProofSchema = createInsertSchema(zkProofs).omit({ id: true, createdAt: true, verifiedAt: true });
export const insertReputationScoreSchema = createInsertSchema(reputationScores).omit({ id: true, lastUpdated: true });
export const insertNegotiationSchema = createInsertSchema(negotiations).omit({ id: true, startedAt: true, completedAt: true });

// Define types
export type Swarm = typeof swarms.$inferSelect;
export type InsertSwarm = z.infer<typeof insertSwarmSchema>;

export type SwarmParticipant = typeof swarmParticipants.$inferSelect;
export type InsertSwarmParticipant = z.infer<typeof insertSwarmParticipantSchema>;

export type ZkProof = typeof zkProofs.$inferSelect;
export type InsertZkProof = z.infer<typeof insertZkProofSchema>;

export type ReputationScore = typeof reputationScores.$inferSelect;
export type InsertReputationScore = z.infer<typeof insertReputationScoreSchema>;

export type Negotiation = typeof negotiations.$inferSelect;
export type InsertNegotiation = z.infer<typeof insertNegotiationSchema>;