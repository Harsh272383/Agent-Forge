import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { Agent } from "@/lib/types";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet-async";

export default function MyAgents() {
  const { toast } = useToast();
  const [filter, setFilter] = useState<"all" | "active" | "inactive">("all");
  
  const { data: agents, isLoading, error } = useQuery<Agent[]>({
    queryKey: ['/api/agents'],
  });

  const toggleAgentStatus = async (agent: Agent) => {
    try {
      await apiRequest('POST', `/api/agents/${agent.id}/toggle`, {});
      
      // Invalidate queries to refresh data
      await queryClient.invalidateQueries({ queryKey: ['/api/agents'] });
      
      toast({
        title: `Agent ${agent.status === 'active' ? 'Deactivated' : 'Activated'}`,
        description: `${agent.name} is now ${agent.status === 'active' ? 'inactive' : 'active'}.`,
      });
    } catch (error) {
      console.error(`Error toggling agent status:`, error);
      toast({
        title: "Operation Failed",
        description: "Failed to change agent status.",
        variant: "destructive",
      });
    }
  };

  const filteredAgents = agents?.filter(agent => {
    if (filter === "all") return true;
    return filter === "active" ? agent.status === "active" : agent.status !== "active";
  });

  return (
    <>
      <Helmet>
        <title>My Agents | AgentForge - On-Chain AI Agents</title>
        <meta name="description" content="Manage your deployed AI agents, monitor their performance, and control their activities on the blockchain." />
      </Helmet>

      <div className="mb-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <h1 className="text-3xl font-display font-bold mb-3">
              <span className="text-white">My </span>
              <span className="text-neonBlue neon-text">Agents</span>
            </h1>
            <p className="text-textLight opacity-80 max-w-2xl">
              Manage your deployed AI agents, monitor their performance, and control their activities.
            </p>
          </div>
          <Link href="/create-agent">
            <Button className="mt-4 md:mt-0 bg-gradient-to-r from-neonBlue to-neonPurple text-white font-medium hover:shadow-lg hover:shadow-neonBlue/30">
              <i className="ri-add-line mr-2"></i>
              <span>Create New Agent</span>
            </Button>
          </Link>
        </div>
      </div>
      
      {/* Filter Controls */}
      <div className="glass-card rounded-xl p-4 mb-8">
        <div className="flex flex-wrap items-center gap-4">
          <div className="font-medium text-sm">Filter:</div>
          <div className="flex space-x-2">
            <Button 
              variant={filter === "all" ? "default" : "outline"} 
              size="sm" 
              onClick={() => setFilter("all")}
              className={filter === "all" ? "bg-neonBlue text-white" : "border-cardBorder"}
            >
              All Agents
            </Button>
            <Button 
              variant={filter === "active" ? "default" : "outline"} 
              size="sm" 
              onClick={() => setFilter("active")}
              className={filter === "active" ? "bg-neonGreen text-white" : "border-cardBorder"}
            >
              Active
            </Button>
            <Button 
              variant={filter === "inactive" ? "default" : "outline"} 
              size="sm" 
              onClick={() => setFilter("inactive")}
              className={filter === "inactive" ? "bg-muted text-white" : "border-cardBorder"}
            >
              Inactive
            </Button>
          </div>
        </div>
      </div>
      
      {/* Agents List */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="glass-card animate-pulse">
              <CardContent className="p-5">
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-muted mr-3"></div>
                    <div className="space-y-2">
                      <div className="h-4 w-24 bg-muted rounded"></div>
                      <div className="h-3 w-16 bg-muted rounded"></div>
                    </div>
                  </div>
                  <div className="h-8 w-20 bg-muted rounded"></div>
                </div>
                <div className="space-y-2 mb-4">
                  <div className="h-3 w-full bg-muted rounded"></div>
                  <div className="h-3 w-full bg-muted rounded"></div>
                </div>
                <div className="flex justify-between mb-4">
                  <div className="h-8 w-24 bg-muted rounded"></div>
                  <div className="h-8 w-24 bg-muted rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : error ? (
        <div className="text-center py-10">
          <div className="text-destructive mb-2">Error loading your agents</div>
          <Button variant="outline" onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/agents'] })}>
            Try Again
          </Button>
        </div>
      ) : filteredAgents && filteredAgents.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAgents.map((agent) => (
            <Card key={agent.id} className="glass-card hover:border-neonBlue transition-all">
              <CardContent className="p-5">
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center">
                    <div className={`w-10 h-10 rounded-full bg-opacity-20 flex items-center justify-center mr-3 ${
                      agent.agentType === "data" ? "bg-neonBlue" : 
                      agent.agentType === "trader" ? "bg-neonPurple" : 
                      agent.agentType === "monitor" ? "bg-warning" : "bg-neonGreen"
                    }`}>
                      <i className={`text-xl ${
                        agent.agentType === "data" ? "ri-database-2-line text-neonBlue" : 
                        agent.agentType === "trader" ? "ri-exchange-funds-line text-neonPurple" : 
                        agent.agentType === "monitor" ? "ri-eye-line text-warning" : "ri-cpu-line text-neonGreen"
                      }`}></i>
                    </div>
                    <div>
                      <h3 className="font-medium text-white">{agent.name}</h3>
                      <div className="text-xs text-muted-foreground flex items-center">
                        <i className="ri-wallet-3-line mr-1"></i>
                        {agent.walletAddress || "No wallet"}
                      </div>
                    </div>
                  </div>
                  <Button 
                    variant={agent.status === "active" ? "destructive" : "outline"}
                    size="sm"
                    className={agent.status === "active" ? "" : "border-neonGreen text-neonGreen hover:text-white hover:bg-neonGreen"}
                    onClick={() => toggleAgentStatus(agent)}
                  >
                    {agent.status === "active" ? "Stop" : "Start"}
                  </Button>
                </div>
                
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {agent.description || `A ${agent.agentType} agent operating on ${agent.networks.join(", ")}`}
                </p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {agent.networks.map((network) => (
                    <div key={network} className="px-2 py-1 bg-cardBg rounded-full text-xs border border-cardBorder">
                      {network}
                    </div>
                  ))}
                </div>
                
                <div className="flex justify-between">
                  <Link href={`/agents/${agent.id}`}>
                    <Button variant="outline" size="sm" className="border-neonBlue text-neonBlue hover:bg-neonBlue/10">
                      View Details
                    </Button>
                  </Link>
                  <span className="text-xs flex items-center">
                    {agent.status === "active" ? (
                      <>
                        <span className="w-2 h-2 rounded-full bg-neonGreen mr-2"></span>
                        Active
                      </>
                    ) : (
                      <>
                        <span className="w-2 h-2 rounded-full bg-muted mr-2"></span>
                        Inactive
                      </>
                    )}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="glass-card rounded-xl p-8 text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
            <i className="ri-robot-line text-2xl"></i>
          </div>
          <h3 className="text-xl font-medium mb-2">No Agents Found</h3>
          <p className="text-muted-foreground mb-6">You haven't created any agents yet or none match your filter.</p>
          <Link href="/create-agent">
            <Button className="bg-gradient-to-r from-neonBlue to-neonPurple text-white">
              Create Your First Agent
            </Button>
          </Link>
        </div>
      )}
    </>
  );
}
