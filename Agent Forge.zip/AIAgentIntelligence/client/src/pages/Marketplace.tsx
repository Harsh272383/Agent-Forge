import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AgentMarketplaceItems from "@/components/AgentMarketplaceItems";
import { Helmet } from "react-helmet-async";

type AgentType = "all" | "monitor" | "trader" | "data" | "custom";

export default function Marketplace() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTab, setSelectedTab] = useState<AgentType>("all");

  return (
    <>
      <Helmet>
        <title>Agent Marketplace | AgentForge - On-Chain AI Agents</title>
        <meta name="description" content="Browse and deploy pre-built AI agents for blockchain monitoring, trading, data collection, and custom tasks from the AgentForge marketplace." />
      </Helmet>

      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold mb-3">
          <span className="text-white">Agent </span>
          <span className="text-neonBlue neon-text">Marketplace</span>
        </h1>
        <p className="text-textLight opacity-80 max-w-2xl">
          Browse and deploy pre-built AI agents that can be customized to your needs. All agents come with secure wallet integration and on-chain verification.
        </p>
      </div>

      {/* Search and filter section */}
      <div className="glass-card rounded-xl p-6 mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-grow">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search agents..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-bgDarker border border-cardBorder rounded-lg text-white"
              />
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
                <i className="ri-search-line text-muted-foreground"></i>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="border-cardBorder hover:border-neonBlue">
              <i className="ri-filter-2-line mr-2"></i> Filters
            </Button>
            <Button variant="outline" className="border-cardBorder hover:border-neonBlue">
              <i className="ri-sort-desc-line mr-2"></i> Sort
            </Button>
          </div>
        </div>

        {/* Tabs for agent types */}
        <div className="mt-4">
          <Tabs defaultValue="all" onValueChange={(value) => setSelectedTab(value as AgentType)}>
            <TabsList className="bg-bgDarker">
              <TabsTrigger value="all">All Agents</TabsTrigger>
              <TabsTrigger value="monitor">Monitor & Alert</TabsTrigger>
              <TabsTrigger value="trader">Trading</TabsTrigger>
              <TabsTrigger value="data">Data Collection</TabsTrigger>
              <TabsTrigger value="custom">Custom</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* Marketplace items */}
      <AgentMarketplaceItems limit={12} showViewAll={false} />

      {/* Promotional section */}
      <div className="mt-16 glass-card rounded-xl p-8 border border-neonBlue/30">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-2/3 mb-6 md:mb-0 md:pr-8">
            <h2 className="text-2xl font-display font-bold mb-3">
              <span className="text-white">Create Your Own </span>
              <span className="text-neonBlue">Agent Templates</span>
            </h2>
            <p className="text-textLight opacity-80 mb-4">
              Have a powerful agent worth sharing? List your own agent templates on the marketplace and earn from each deployment. Join our growing ecosystem of agent builders and users.
            </p>
            <Button className="bg-gradient-to-r from-neonBlue to-neonPurple text-white hover:shadow-lg hover:shadow-neonBlue/20">
              <i className="ri-upload-cloud-2-line mr-2"></i> Submit Your Template
            </Button>
          </div>
          <div className="md:w-1/3 flex justify-center">
            <div className="w-40 h-40 rounded-full bg-gradient-to-br from-neonPurple/30 to-neonBlue/30 flex items-center justify-center relative">
              <i className="ri-code-box-line text-6xl text-neonBlue"></i>
              <div className="absolute inset-0 rounded-full animate-pulse opacity-20 bg-neonBlue"></div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
