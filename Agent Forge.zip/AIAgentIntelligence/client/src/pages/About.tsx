import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import Layout from "../components/Layout";
import { Helmet } from "react-helmet-async";

export default function About() {
  const { data: aboutData, isLoading } = useQuery({
    queryKey: ['/api/about'],
  });

  return (
    <Layout>
      <Helmet>
        <title>About | AI Agents Platform</title>
        <meta name="description" content="Learn about the AI Agents Platform, developed by Harsh Patil for the Berlin Hackathon 2025." />
      </Helmet>
      
      <div className="container mx-auto py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-8">About AI Agents Platform</h1>
          
          {isLoading ? (
            <div className="flex justify-center">
              <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : aboutData ? (
            <>
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle className="text-2xl">Developer</CardTitle>
                  <CardDescription>Project Information</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h3 className="font-semibold text-lg">Developer</h3>
                      <p className="text-xl">{aboutData.developer}</p>
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">Role</h3>
                      <p className="text-xl">{aboutData.role}</p>
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">Project</h3>
                      <p className="text-xl">{aboutData.project}</p>
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">Version</h3>
                      <p className="text-xl">{aboutData.version}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <h2 className="text-2xl font-bold mb-4">Advanced Technologies</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
                {aboutData.technologies.map((tech: string, index: number) => (
                  <Badge key={index} variant="outline" className="text-base py-3 justify-center">
                    {tech}
                  </Badge>
                ))}
              </div>
              
              <Separator className="my-8" />
              
              <div className="prose dark:prose-invert max-w-none">
                <h2>Platform Description</h2>
                <p>
                  The AI Agents Platform represents a cutting-edge approach to blockchain-based autonomous agent coordination. 
                  Created for the AI Agents Berlin Hackathon 2025, this platform showcases what's possible at the intersection 
                  of artificial intelligence and blockchain technology with a futuristic vision looking ahead to 2050.
                </p>
                
                <h3>Key Features</h3>
                <ul>
                  <li>
                    <strong>Multi-agent Swarm Coordination</strong> - Enables multiple AI agents to work together 
                    in a coordinated swarm, sharing resources and information while maintaining autonomous operation.
                  </li>
                  <li>
                    <strong>Zero-knowledge Proof Verification</strong> - Implements cryptographic verification allowing 
                    agents to prove computational results without revealing sensitive data.
                  </li>
                  <li>
                    <strong>On-chain Reputation System</strong> - Tracks agent reliability, performance, and trustworthiness 
                    through an immutable on-chain reputation system.
                  </li>
                  <li>
                    <strong>Autonomous Negotiation</strong> - Agents can autonomously negotiate terms, resources and 
                    actions with other agents using formalized negotiation protocols.
                  </li>
                  <li>
                    <strong>Real-time Communication</strong> - Implemented with WebSockets for instant updates and 
                    agent-to-agent messaging across the platform.
                  </li>
                  <li>
                    <strong>Advanced ML/AI Capabilities</strong> - Utilizes quantum computing algorithms, neural networks, 
                    and deep learning for enhanced agent intelligence and decision-making capabilities.
                  </li>
                </ul>
              </div>
            </>
          ) : (
            <div className="text-center p-8 border rounded-lg">
              <p className="text-xl">Unable to load about information</p>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}