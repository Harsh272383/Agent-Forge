import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import CreateAgentForm from "@/components/CreateAgentForm";
import { Card, CardContent } from "@/components/ui/card";
import { Helmet } from "react-helmet-async";

export default function CreateAgent() {
  return (
    <>
      <Helmet>
        <title>Create Agent | AgentForge - Build Custom AI Agents</title>
        <meta name="description" content="Create autonomous AI agents that can operate on blockchain networks, execute tasks, and interact with decentralized applications without human intervention." />
      </Helmet>

      <div className="mb-8">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-display font-bold mb-3">
            <span className="text-white">Create New </span>
            <span className="text-neonBlue neon-text">Agent</span>
          </h1>
          <Link href="/my-agents">
            <Button variant="outline" className="border-cardBorder hover:border-neonBlue">
              <i className="ri-arrow-left-line mr-2"></i> My Agents
            </Button>
          </Link>
        </div>
        <p className="text-textLight opacity-80 max-w-2xl">
          Design autonomous AI agents that operate on blockchain networks, execute tasks, and interact with decentralized applications.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="col-span-1 lg:col-span-2">
          <Card className="glass-card rounded-xl">
            <CardContent className="p-6">
              <h2 className="text-xl font-display font-medium mb-6">Agent Configuration</h2>
              <CreateAgentForm />
            </CardContent>
          </Card>
        </div>

        <div className="col-span-1">
          <Card className="glass-card rounded-xl mb-6">
            <CardContent className="p-6">
              <h3 className="font-medium text-lg mb-4">Agent Types</h3>
              
              <div className="space-y-4">
                <div className="p-3 rounded-lg bg-opacity-20 bg-neonBlue border border-neonBlue">
                  <div className="flex items-center mb-2">
                    <div className="w-8 h-8 rounded-full bg-neonBlue bg-opacity-20 flex items-center justify-center mr-3">
                      <i className="ri-eye-line text-neonBlue"></i>
                    </div>
                    <h4 className="font-medium">Monitor & Alert</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Monitors blockchain activity and sends alerts based on predefined conditions.
                  </p>
                </div>
                
                <div className="p-3 rounded-lg bg-opacity-20 bg-neonPurple border border-neonPurple/50">
                  <div className="flex items-center mb-2">
                    <div className="w-8 h-8 rounded-full bg-neonPurple bg-opacity-20 flex items-center justify-center mr-3">
                      <i className="ri-exchange-funds-line text-neonPurple"></i>
                    </div>
                    <h4 className="font-medium">Trading Bot</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Executes trading strategies on DEXes with automated decision-making.
                  </p>
                </div>
                
                <div className="p-3 rounded-lg bg-opacity-20 bg-neonGreen border border-neonGreen/50">
                  <div className="flex items-center mb-2">
                    <div className="w-8 h-8 rounded-full bg-neonGreen bg-opacity-20 flex items-center justify-center mr-3">
                      <i className="ri-database-2-line text-neonGreen"></i>
                    </div>
                    <h4 className="font-medium">Data Collector</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Gathers and processes on-chain data for analysis and insights.
                  </p>
                </div>
                
                <div className="p-3 rounded-lg bg-opacity-20 bg-warning border border-warning/50">
                  <div className="flex items-center mb-2">
                    <div className="w-8 h-8 rounded-full bg-warning bg-opacity-20 flex items-center justify-center mr-3">
                      <i className="ri-cpu-line text-warning"></i>
                    </div>
                    <h4 className="font-medium">Custom Logic</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Build specialized agents with custom functionality for specific use cases.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="glass-card rounded-xl">
            <CardContent className="p-6">
              <h3 className="font-medium text-lg mb-4">Network Information</h3>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <img src="https://cryptologos.cc/logos/ethereum-eth-logo.svg" alt="Ethereum" className="w-5 h-5 mr-2" />
                    <span>Ethereum</span>
                  </div>
                  <span className="text-xs px-2 py-1 bg-neonGreen/20 text-neonGreen rounded-full">Active</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <img src="https://cryptologos.cc/logos/polygon-matic-logo.svg" alt="Polygon" className="w-5 h-5 mr-2" />
                    <span>Polygon</span>
                  </div>
                  <span className="text-xs px-2 py-1 bg-neonGreen/20 text-neonGreen rounded-full">Active</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <img src="https://cryptologos.cc/logos/arbitrum-arb-logo.svg" alt="Arbitrum" className="w-5 h-5 mr-2" />
                    <span>Arbitrum</span>
                  </div>
                  <span className="text-xs px-2 py-1 bg-neonGreen/20 text-neonGreen rounded-full">Active</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <img src="https://cryptologos.cc/logos/optimism-op-logo.svg" alt="Optimism" className="w-5 h-5 mr-2" />
                    <span>Optimism</span>
                  </div>
                  <span className="text-xs px-2 py-1 bg-muted/30 text-muted-foreground rounded-full">Coming Soon</span>
                </div>
              </div>
              
              <div className="mt-6 pt-6 border-t border-cardBorder">
                <h4 className="font-medium mb-2">Gas Costs</h4>
                <p className="text-sm text-muted-foreground mb-4">
                  Deploying an agent requires a one-time gas fee plus initial funding for on-chain actions.
                </p>
                <div className="text-xs text-muted-foreground">
                  <div className="flex justify-between mb-1">
                    <span>Average Deployment:</span>
                    <span>0.003 - 0.007 ETH</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Recommended Funding:</span>
                    <span>≥ 0.05 ETH</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
