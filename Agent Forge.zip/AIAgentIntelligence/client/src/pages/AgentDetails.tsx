import { useState, useEffect } from "react";
import { useParams, useLocation, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { 
  Card, 
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { executeAgentCommand } from "@/lib/aiService";
import { Agent, AgentTask } from "@/lib/types";
import { formatDistanceToNow } from "date-fns";

export default function AgentDetails() {
  const { id } = useParams<{ id: string }>();
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const [currentCommand, setCurrentCommand] = useState<string>("");
  const [isExecuting, setIsExecuting] = useState(false);

  // Query agent details
  const { 
    data: agent, 
    isLoading, 
    error,
    refetch 
  } = useQuery<Agent>({
    queryKey: [`/api/agents/${id}`],
  });

  // Query agent tasks
  const { 
    data: tasks, 
    isLoading: tasksLoading 
  } = useQuery<AgentTask[]>({
    queryKey: [`/api/agents/${id}/tasks`],
    enabled: !!id,
  });

  // Handle command execution
  const handleExecuteCommand = async () => {
    if (!currentCommand.trim() || !agent) return;
    
    setIsExecuting(true);
    
    try {
      // Execute the command via API
      await apiRequest("POST", `/api/agents/${id}/execute`, {
        command: currentCommand,
        params: {}
      });
      
      // Invalidate queries to refresh data
      await queryClient.invalidateQueries({ queryKey: [`/api/agents/${id}/tasks`] });
      
      toast({
        title: "Command Executed",
        description: `Successfully executed: ${currentCommand}`,
      });
      
      // Clear the command
      setCurrentCommand("");
    } catch (error) {
      console.error("Error executing command:", error);
      toast({
        title: "Execution Failed",
        description: "There was an error executing the command. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsExecuting(false);
    }
  };

  // Toggle agent status (active/inactive)
  const toggleAgentStatus = async () => {
    if (!agent) return;
    
    try {
      await apiRequest("POST", `/api/agents/${id}/toggle`, {});
      
      // Refresh agent data
      refetch();
      
      toast({
        title: `Agent ${agent.status === "active" ? "Stopped" : "Started"}`,
        description: `${agent.name} is now ${agent.status === "active" ? "inactive" : "active"}.`,
      });
    } catch (error) {
      console.error("Error toggling agent status:", error);
      toast({
        title: "Status Change Failed",
        description: "There was an error changing the agent's status.",
        variant: "destructive",
      });
    }
  };

  // Handle agent deletion
  const handleDeleteAgent = async () => {
    if (!agent) return;
    
    const confirmed = window.confirm(`Are you sure you want to delete ${agent.name}? This action cannot be undone.`);
    
    if (confirmed) {
      try {
        await apiRequest("DELETE", `/api/agents/${id}`, {});
        
        toast({
          title: "Agent Deleted",
          description: `${agent.name} has been successfully deleted.`,
        });
        
        // Navigate back to My Agents page
        navigate("/my-agents");
      } catch (error) {
        console.error("Error deleting agent:", error);
        toast({
          title: "Deletion Failed",
          description: "There was an error deleting the agent.",
          variant: "destructive",
        });
      }
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="animate-pulse flex flex-col items-center">
          <div className="h-12 w-64 bg-muted rounded mb-6"></div>
          <div className="h-4 w-96 bg-muted rounded mb-8"></div>
          <div className="w-full max-w-3xl h-96 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  if (error || !agent) {
    return (
      <div className="text-center py-16">
        <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-destructive/20 flex items-center justify-center">
          <i className="ri-error-warning-line text-2xl text-destructive"></i>
        </div>
        <h2 className="text-xl font-medium mb-2">Agent Not Found</h2>
        <p className="text-muted-foreground mb-6">The agent you're looking for doesn't exist or you don't have access to it.</p>
        <Link href="/my-agents">
          <Button variant="outline" className="border-neonBlue text-neonBlue hover:bg-neonBlue/10">
            Return to My Agents
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{agent.name} | AgentForge</title>
        <meta name="description" content={`Manage and monitor ${agent.name}, a ${agent.agentType} agent deployed on ${agent.networks.join(", ")}.`} />
      </Helmet>

      <div className="mb-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
          <div className="flex items-center">
            <div className={`w-12 h-12 rounded-full bg-opacity-20 flex items-center justify-center mr-4 ${
              agent.agentType === "data" ? "bg-neonBlue" : 
              agent.agentType === "trader" ? "bg-neonPurple" : 
              agent.agentType === "monitor" ? "bg-warning" : "bg-neonGreen"
            }`}>
              <i className={`text-2xl ${
                agent.agentType === "data" ? "ri-database-2-line text-neonBlue" : 
                agent.agentType === "trader" ? "ri-exchange-funds-line text-neonPurple" : 
                agent.agentType === "monitor" ? "ri-eye-line text-warning" : "ri-cpu-line text-neonGreen"
              }`}></i>
            </div>
            <div>
              <div className="flex items-center">
                <h1 className="text-3xl font-display font-bold mr-3">{agent.name}</h1>
                <div className={`px-2 py-0.5 rounded-full text-xs flex items-center ${
                  agent.status === "active" ? "bg-neonGreen/20 text-neonGreen" : "bg-muted/30 text-muted-foreground"
                }`}>
                  <span className={`w-2 h-2 rounded-full mr-1.5 ${
                    agent.status === "active" ? "bg-neonGreen" : "bg-muted"
                  }`}></span>
                  {agent.status === "active" ? "Active" : "Inactive"}
                </div>
              </div>
              <p className="text-textLight opacity-80 mt-1">
                {agent.description || `A ${agent.agentType} agent operating on ${agent.networks.join(", ")}`}
              </p>
            </div>
          </div>
          <div className="flex space-x-3 mt-4 md:mt-0">
            <Button 
              variant={agent.status === "active" ? "destructive" : "outline"}
              className={agent.status === "active" ? "" : "border-neonGreen text-neonGreen hover:text-white hover:bg-neonGreen"}
              onClick={toggleAgentStatus}
            >
              {agent.status === "active" ? (
                <><i className="ri-stop-line mr-2"></i> Stop Agent</>
              ) : (
                <><i className="ri-play-line mr-2"></i> Start Agent</>
              )}
            </Button>
            <Button variant="outline" onClick={handleDeleteAgent} className="border-destructive text-destructive hover:bg-destructive/10">
              <i className="ri-delete-bin-line mr-2"></i> Delete
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Agent Status Card */}
        <Card className="glass-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-medium">Agent Status</h3>
                <p className="text-sm text-muted-foreground">Performance metrics</p>
              </div>
              <Button variant="outline" size="sm" className="border-cardBorder hover:border-neonBlue" onClick={() => refetch()}>
                <i className="ri-refresh-line mr-1"></i> Refresh
              </Button>
            </div>
            
            <div className="space-y-6">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Uptime</span>
                  <span>{agent.performanceData?.uptime || "0h"}</span>
                </div>
                <Progress value={80} className="h-2 bg-bgDark" indicatorClassName="bg-gradient-to-r from-neonBlue to-neonPurple" />
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Balance</span>
                  <span>{agent.balance} ETH</span>
                </div>
                <Progress value={agent.balance ? (agent.balance / 0.1) * 100 : 0} max={100} className="h-2 bg-bgDark" indicatorClassName="bg-gradient-to-r from-neonGreen to-neonBlue" />
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Tasks Completed</span>
                  <span>{tasks?.filter(t => t.status === "completed").length || 0}</span>
                </div>
                <Progress value={tasks?.filter(t => t.status === "completed").length || 0} max={tasks?.length || 1} className="h-2 bg-bgDark" indicatorClassName="bg-gradient-to-r from-neonPurple to-neonBlue" />
              </div>
              
              <div className="pt-4 border-t border-cardBorder">
                <div className="text-sm font-medium mb-2">Networks</div>
                <div className="flex flex-wrap gap-2">
                  {agent.networks.map((network) => (
                    <div key={network} className="px-2 py-1 bg-cardBg rounded-full text-xs border border-cardBorder">
                      {network}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Agent Config */}
        <Card className="glass-card">
          <CardContent className="pt-6">
            <h3 className="text-lg font-medium mb-4">Configuration</h3>
            
            <div className="space-y-4">
              <div>
                <div className="text-sm text-muted-foreground mb-1">Agent Type</div>
                <div className="font-medium capitalize">{agent.agentType}</div>
              </div>
              
              <div>
                <div className="text-sm text-muted-foreground mb-1">Wallet Address</div>
                <div className="font-mono text-sm bg-bgDarker p-2 rounded border border-cardBorder overflow-x-auto">
                  {agent.walletAddress || "No wallet connected"}
                </div>
              </div>
              
              <div>
                <div className="text-sm text-muted-foreground mb-1">Configuration</div>
                <div className="font-mono text-xs bg-bgDarker p-2 rounded border border-cardBorder overflow-x-auto h-[120px] overflow-y-auto">
                  <pre>{JSON.stringify(agent.config || {}, null, 2)}</pre>
                </div>
              </div>
            </div>
            
            <div className="mt-6 pt-4 border-t border-cardBorder">
              <Button variant="outline" className="w-full border-neonBlue text-neonBlue hover:bg-neonBlue/10">
                <i className="ri-settings-3-line mr-2"></i> Edit Configuration
              </Button>
            </div>
          </CardContent>
        </Card>
        
        {/* Command Console */}
        <Card className="glass-card">
          <CardContent className="pt-6">
            <h3 className="text-lg font-medium mb-4">Agent Console</h3>
            
            <div className="mb-4 font-mono text-xs bg-bgDarker p-3 rounded border border-cardBorder overflow-x-auto h-[180px] overflow-y-auto">
              <div className="text-neonGreen">// Agent Console Ready</div>
              <div className="text-muted-foreground">// Connected to {agent.networks.join(", ")}</div>
              <div className="text-muted-foreground">// Type a command below</div>
              
              {tasks?.slice(0, 5).map((task, i) => (
                <div key={i} className="mt-2">
                  <div className="text-neonBlue">$ {task.taskType}</div>
                  <div className={task.status === "completed" ? "text-neonGreen" : "text-destructive"}>
                    {task.status === "completed" ? "Success" : "Failed"}: {task.output ? JSON.stringify(task.output).slice(0, 30) + "..." : task.error || "No output"}
                  </div>
                </div>
              ))}
            </div>
            
            <div className="flex space-x-2">
              <input
                type="text"
                value={currentCommand}
                onChange={(e) => setCurrentCommand(e.target.value)}
                placeholder="Enter command..."
                className="flex-1 bg-bgDarker border border-cardBorder rounded-lg px-4 py-2 text-white focus:border-neonBlue outline-none"
                disabled={agent.status !== "active"}
              />
              <Button
                onClick={handleExecuteCommand}
                disabled={!currentCommand.trim() || agent.status !== "active" || isExecuting}
                className="bg-neonBlue text-white hover:bg-neonBlue/90"
              >
                {isExecuting ? 
                  <i className="ri-loader-4-line animate-spin"></i> : 
                  <i className="ri-send-plane-fill"></i>
                }
              </Button>
            </div>
            
            {agent.status !== "active" && (
              <div className="mt-2 text-xs text-destructive">
                Agent must be active to execute commands.
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Task History */}
      <Card className="glass-card mb-8">
        <CardHeader>
          <CardTitle>Task History</CardTitle>
          <CardDescription>
            Recent tasks executed by the agent
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList className="mb-6">
              <TabsTrigger value="all">All Tasks</TabsTrigger>
              <TabsTrigger value="completed">Completed</TabsTrigger>
              <TabsTrigger value="failed">Failed</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all" className="mt-0">
              {tasksLoading ? (
                <div className="animate-pulse space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-16 bg-muted rounded"></div>
                  ))}
                </div>
              ) : tasks && tasks.length > 0 ? (
                <div className="border rounded-lg border-cardBorder overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-bgDarker">
                      <tr>
                        <th className="text-left p-3 text-sm">Task Type</th>
                        <th className="text-left p-3 text-sm">Status</th>
                        <th className="text-left p-3 text-sm">Network</th>
                        <th className="text-left p-3 text-sm">Time</th>
                        <th className="text-left p-3 text-sm">Result</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tasks.map((task) => (
                        <tr key={task.id} className="border-t border-cardBorder hover:bg-bgDarker/50">
                          <td className="p-3 text-sm font-medium">{task.taskType}</td>
                          <td className="p-3 text-sm">
                            <span className={`px-2 py-0.5 rounded-full text-xs ${
                              task.status === "completed" ? "bg-neonGreen/20 text-neonGreen" : 
                              task.status === "failed" ? "bg-destructive/20 text-destructive" : 
                              "bg-warning/20 text-warning"
                            }`}>
                              {task.status}
                            </span>
                          </td>
                          <td className="p-3 text-sm">{task.network || "-"}</td>
                          <td className="p-3 text-sm text-muted-foreground">
                            {task.startTime ? formatDistanceToNow(new Date(task.startTime), { addSuffix: true }) : "-"}
                          </td>
                          <td className="p-3 text-sm font-mono">
                            {task.status === "failed" ? 
                              <span className="text-destructive">{task.error?.slice(0, 30) || "Error"}</span> : 
                              <span className="text-muted-foreground">
                                {task.transactionHash ? 
                                  task.transactionHash.slice(0, 10) + "..." : 
                                  "No tx hash"}
                              </span>
                            }
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-12 text-muted-foreground">
                  <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
                    <i className="ri-history-line text-xl"></i>
                  </div>
                  <p>No tasks have been executed yet</p>
                  <p className="text-sm mt-1">Execute a command to see results here</p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="completed" className="mt-0">
              {/* Similar to all tasks but filtered */}
            </TabsContent>
            
            <TabsContent value="failed" className="mt-0">
              {/* Similar to all tasks but filtered */}
            </TabsContent>
            
            <TabsContent value="pending" className="mt-0">
              {/* Similar to all tasks but filtered */}
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="border-t border-cardBorder pt-6 flex justify-between">
          <Button variant="outline" className="border-cardBorder">
            <i className="ri-download-2-line mr-2"></i> Export Tasks
          </Button>
          <Button variant="outline" className="border-neonBlue text-neonBlue hover:bg-neonBlue/10" onClick={() => queryClient.invalidateQueries({ queryKey: [`/api/agents/${id}/tasks`] })}>
            <i className="ri-refresh-line mr-2"></i> Refresh Tasks
          </Button>
        </CardFooter>
      </Card>
      
      {/* Analytics Dashboard */}
      <Card className="glass-card">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Performance Analytics</CardTitle>
            <CardDescription>
              Agent performance metrics and insights
            </CardDescription>
          </div>
          <Button variant="outline" className="border-cardBorder">
            <i className="ri-calendar-line mr-2"></i> Last 7 Days
          </Button>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] flex items-center justify-center bg-bgDarker/50 rounded-lg border border-cardBorder">
            <div className="text-center">
              <i className="ri-line-chart-line text-4xl text-neonBlue mb-4 block"></i>
              <h4 className="font-medium mb-2">Analytics Dashboard</h4>
              <p className="text-sm text-muted-foreground max-w-md mx-auto">
                Detailed analytics will be available after the agent has processed more tasks.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
