import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import AgentNetworkVisualization from "@/components/AgentNetworkVisualization";
import ActiveAgentStats from "@/components/ActiveAgentStats";
import AgentMarketplaceItems from "@/components/AgentMarketplaceItems";
import CreateAgentForm from "@/components/CreateAgentForm";
import { Helmet } from "react-helmet-async";

export default function Dashboard() {
  return (
    <>
      <Helmet>
        <title>Dashboard | AgentForge - Build On-Chain AI Agents</title>
        <meta name="description" content="Build, deploy, and manage autonomous AI agents that operate on-chain, performing tasks and providing services without human intervention." />
      </Helmet>

      {/* Hero Section */}
      <div className="mb-8 mt-2">
        <h1 className="text-3xl sm:text-4xl font-display font-bold mb-3">
          <span className="text-white">Build</span>
          <span className="text-neonBlue neon-text"> Autonomous AI Agents</span>
        </h1>
        <p className="text-textLight opacity-80 max-w-2xl">
          Create, deploy, and manage AI agents that autonomously operate on-chain, performing tasks and providing services without human intervention.
        </p>
        
        <div className="mt-6 flex flex-wrap gap-4">
          <Link href="/create-agent">
            <Button className="relative inline-flex group items-center px-5 py-2.5 rounded-lg bg-gradient-to-r from-neonBlue to-neonPurple text-white font-medium transition-all hover:shadow-lg hover:shadow-neonBlue/30">
              <i className="ri-add-line mr-2"></i>
              <span>Create New Agent</span>
              <span className="absolute -inset-0.5 rounded-lg bg-gradient-to-r from-neonBlue to-neonPurple -z-10 group-hover:blur-md transition-all"></span>
            </Button>
          </Link>
          
          <Link href="/marketplace">
            <Button variant="outline" className="px-5 py-2.5 rounded-lg border border-neonPurple bg-transparent text-white font-medium hover:bg-neonPurple/10 transition-all">
              <i className="ri-store-2-line mr-2"></i>
              <span>Browse Marketplace</span>
            </Button>
          </Link>
        </div>
      </div>

      {/* Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <AgentNetworkVisualization />
        <ActiveAgentStats />
      </div>
      
      {/* Marketplace section */}
      <AgentMarketplaceItems />
      
      {/* Create Agent Section */}
      <div className="mt-10 glass-card rounded-xl p-6 border border-cardBorder">
        <div className="flex flex-col lg:flex-row">
          <div className="lg:w-1/2 lg:pr-8 mb-6 lg:mb-0">
            <h2 className="font-display font-bold text-2xl text-white mb-3">Create Your Custom Agent</h2>
            <p className="text-textLight opacity-80 mb-6">
              Design an autonomous AI agent that operates on-chain with your custom logic. Our builder system lets you create agents that can monitor, trade, analyze, and interact with blockchain data.
            </p>
            
            <div className="space-y-5">
              <div className="flex items-start">
                <div className="mt-1 w-8 h-8 rounded-full bg-neonBlue bg-opacity-20 flex items-center justify-center shrink-0 mr-4">
                  <i className="ri-code-box-line text-neonBlue"></i>
                </div>
                <div>
                  <h3 className="font-medium text-white">No-Code Builder</h3>
                  <p className="text-sm opacity-70">Intuitive drag-and-drop interface for creating agent logic without coding.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="mt-1 w-8 h-8 rounded-full bg-neonPurple bg-opacity-20 flex items-center justify-center shrink-0 mr-4">
                  <i className="ri-wallet-3-line text-neonPurple"></i>
                </div>
                <div>
                  <h3 className="font-medium text-white">Built-in Wallet</h3>
                  <p className="text-sm opacity-70">Agents get their own wallet for autonomous on-chain interactions.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="mt-1 w-8 h-8 rounded-full bg-neonGreen bg-opacity-20 flex items-center justify-center shrink-0 mr-4">
                  <i className="ri-shield-check-line text-neonGreen"></i>
                </div>
                <div>
                  <h3 className="font-medium text-white">Verified Credentials</h3>
                  <p className="text-sm opacity-70">Secure identity system ensures your agent operates with proper permissions.</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Agent Creation Form */}
          <div className="lg:w-1/2">
            <CreateAgentForm />
          </div>
        </div>
      </div>
    </>
  );
}
