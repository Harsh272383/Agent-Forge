// User type definition
export interface User {
  id: number;
  username: string;
  walletAddress?: string;
  email?: string;
  createdAt: Date;
}

// Agent type definition
export interface Agent {
  id: number;
  userId: number;
  name: string;
  description?: string;
  agentType: AgentType;
  status: AgentStatus;
  networks: string[];
  walletAddress?: string;
  balance?: number;
  config?: Record<string, any>;
  metadata?: Record<string, any>;
  performanceData?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
  lastActive?: Date;
  isPublic: boolean;
}

// Agent template definition
export interface AgentTemplate {
  id: number;
  name: string;
  description: string;
  agentType: AgentType;
  capabilities?: string[];
  config?: Record<string, any>;
  price: number;
  creator?: string;
  downloads: number;
  rating: number;
  reviewCount: number;
  networks?: string[];
  imagePath?: string;
  isPopular: boolean;
  isNew: boolean;
  createdAt: Date;
}

// Agent task definition
export interface AgentTask {
  id: number;
  agentId: number;
  taskType: string;
  status: TaskStatus;
  input?: Record<string, any>;
  output?: Record<string, any>;
  transactionHash?: string;
  network?: string;
  startTime: Date;
  endTime?: Date | null;
  error?: string;
}

// Type definitions for enums
export type AgentType = "monitor" | "trader" | "data" | "custom";
export type AgentStatus = "active" | "inactive" | "error" | "processing";
export type TaskStatus = "pending" | "completed" | "failed";

// Create agent form data type
export interface CreateAgentFormData {
  name: string;
  agentType: AgentType;
  description?: string;
  networks: string[];
  initialFunding: number;
  config?: Record<string, any>;
}

// Web3 provider connection type
export interface Web3Connection {
  connected: boolean;
  address?: string;
  chainId?: number;
  network?: string;
  balance?: string;
}

// Agent command definition
export interface AgentCommand {
  command: string;
  description: string;
  params?: Record<string, any>;
  icon?: string;
}

// Agent capabilities by type
export const AGENT_CAPABILITIES: Record<AgentType, string[]> = {
  monitor: [
    "real-time transaction monitoring",
    "anomaly detection",
    "custom alert system",
    "cross-chain tracking",
    "reporting"
  ],
  trader: [
    "market analysis",
    "trade execution",
    "portfolio rebalancing",
    "stop loss management",
    "profit taking"
  ],
  data: [
    "on-chain data collection",
    "data aggregation",
    "pattern recognition",
    "historical data analysis",
    "visualization preparation"
  ],
  custom: [
    "custom logic implementation",
    "multi-agent coordination",
    "external API integration",
    "customizable triggers",
    "webhook support"
  ]
};

// Supported blockchain networks
export const SUPPORTED_NETWORKS = [
  {
    id: "ethereum",
    name: "Ethereum",
    logo: "https://cryptologos.cc/logos/ethereum-eth-logo.svg",
    isActive: true
  },
  {
    id: "polygon",
    name: "Polygon",
    logo: "https://cryptologos.cc/logos/polygon-matic-logo.svg",
    isActive: true
  },
  {
    id: "arbitrum",
    name: "Arbitrum",
    logo: "https://cryptologos.cc/logos/arbitrum-arb-logo.svg",
    isActive: true
  },
  {
    id: "optimism",
    name: "Optimism",
    logo: "https://cryptologos.cc/logos/optimism-op-logo.svg",
    isActive: false
  }
];
