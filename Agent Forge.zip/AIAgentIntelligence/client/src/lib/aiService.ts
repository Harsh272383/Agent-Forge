import { Agent } from "./types";

// OpenAI API key (would come from environment variables)
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";

/**
 * Call OpenAI API to get AI completions
 */
export const getAICompletion = async (
  prompt: string,
  temperature: number = 0.7,
  maxTokens: number = 500
): Promise<string> => {
  try {
    // For demo purposes, no real API call if no key provided
    if (!OPENAI_API_KEY) {
      console.log("No OpenAI API key found, returning mock response");
      return generateMockResponse(prompt);
    }

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
        messages: [
          {
            role: "system",
            content: "You are an AI assistant that helps operate autonomous blockchain agents."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature,
        max_tokens: maxTokens
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API Error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  } catch (error) {
    console.error("Error calling OpenAI API:", error);
    return generateMockResponse(prompt);
  }
};

/**
 * Get structured AI completion with JSON output
 */
export const getAICompletionJSON = async <T>(
  prompt: string,
  temperature: number = 0.7,
  maxTokens: number = 500
): Promise<T> => {
  try {
    // For demo purposes, no real API call if no key provided
    if (!OPENAI_API_KEY) {
      console.log("No OpenAI API key found, returning mock response");
      return generateMockJSONResponse(prompt) as T;
    }

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
        messages: [
          {
            role: "system",
            content: "You are an AI assistant that helps operate autonomous blockchain agents. Return only valid JSON."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature,
        max_tokens: maxTokens,
        response_format: { type: "json_object" }
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API Error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return JSON.parse(data.choices[0].message.content);
  } catch (error) {
    console.error("Error calling OpenAI API:", error);
    return generateMockJSONResponse(prompt) as T;
  }
};

/**
 * Execute a command for an AI agent
 */
export const executeAgentCommand = async (
  agent: Agent,
  command: string,
  params: Record<string, any> = {}
): Promise<Record<string, any>> => {
  // Create a prompt based on agent type and command
  const prompt = `
    You are an autonomous AI agent named ${agent.name} running on ${agent.networks.join(", ")} blockchain(s).
    Your configuration: ${JSON.stringify(agent.config || {})}.
    
    You received the command "${command}" with the following parameters:
    ${JSON.stringify(params)}
    
    Generate a JSON response as if you executed this command on the blockchain.
    Include relevant fields like success status, transaction hashes (if applicable),
    timestamps, and any output data.
  `;

  return await getAICompletionJSON(prompt, 0.5, 1000);
};

/**
 * Analyze on-chain data with AI
 */
export const analyzeOnChainData = async (
  data: Record<string, any>,
  analysisType: string
): Promise<Record<string, any>> => {
  const prompt = `
    Analyze the following on-chain data for ${analysisType} insights:
    ${JSON.stringify(data)}
    
    Return a JSON object with the analysis results, including:
    - key findings
    - metrics
    - recommendations
    - potential risks (if any)
  `;

  return await getAICompletionJSON(prompt, 0.7, 1000);
};

/**
 * Generate agent strategies with AI
 */
export const generateAgentStrategy = async (
  agentType: string,
  objectives: string[],
  constraints: string[]
): Promise<Record<string, any>> => {
  const prompt = `
    Create a strategy for a ${agentType} blockchain agent with the following objectives:
    ${objectives.map(o => `- ${o}`).join('\n')}
    
    The agent must operate within these constraints:
    ${constraints.map(c => `- ${c}`).join('\n')}
    
    Return a JSON object with:
    - strategy name
    - step-by-step implementation plan
    - required on-chain functions/commands
    - success metrics
    - fallback mechanisms
  `;

  return await getAICompletionJSON(prompt, 0.8, 1500);
};

/**
 * Helper function to generate mock responses for demo purposes
 */
function generateMockResponse(prompt: string): string {
  // Simple response based on agent command keywords
  if (prompt.includes("market analysis")) {
    return "Based on current market conditions, ETH shows strong momentum with increasing volume. Key resistance levels at $2450 and $2580. Consider gradual entry with stop-loss at $2320.";
  } else if (prompt.includes("portfolio")) {
    return "Portfolio analysis complete. Current allocation: 45% ETH, 25% USDC, 15% BTC, 15% ALTs. Recommended rebalance: Increase stablecoin position to 35% given market volatility indicators.";
  } else if (prompt.includes("monitor")) {
    return "Monitoring active. Detected 3 large transactions on target address in the last hour. Total value: 245 ETH. No suspicious pattern detected.";
  } else {
    return "Command processed successfully. Results compiled and stored in agent memory. No actionable insights at this time.";
  }
}

/**
 * Helper function to generate mock JSON responses for demo purposes
 */
function generateMockJSONResponse(prompt: string): Record<string, any> {
  const generateTxHash = () => `0x${Array.from({length: 64}, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
  const timestamp = new Date().toISOString();
  
  // Generate response based on keywords in prompt
  if (prompt.includes("market analysis") || prompt.includes("price")) {
    return {
      status: "success",
      timestamp,
      analysis: {
        trend: "bullish",
        confidence: 0.78,
        timeframe: "short-term",
        keyLevels: {
          support: ["$2250", "$2180"],
          resistance: ["$2450", "$2580"]
        },
        volume: {
          change: "+15%",
          unusual: false
        },
        recommendations: [
          "Consider gradual entry",
          "Set stop-loss at $2320"
        ]
      }
    };
  } else if (prompt.includes("trade") || prompt.includes("swap")) {
    return {
      status: "success",
      timestamp,
      transaction: {
        hash: generateTxHash(),
        from: "0x3a...9f7c",
        to: "0xd8...4e2a",
        gas: 125000,
        gasPrice: "25 gwei"
      },
      trade: {
        fromToken: "ETH",
        toToken: "USDC",
        amount: "1.5 ETH",
        received: "3450 USDC",
        price: "2300 USDC/ETH",
        slippage: "0.2%",
        fee: "0.3%"
      },
      balances: {
        ETH: "5.32",
        USDC: "12450"
      }
    };
  } else if (prompt.includes("monitor") || prompt.includes("alert")) {
    return {
      status: "success",
      timestamp,
      monitoring: {
        address: "0x7f...2e8b",
        duration: "1 hour",
        transactions: {
          count: 3,
          totalValue: "245 ETH",
          largest: "180 ETH"
        },
        alerts: [{
          type: "large_transfer",
          severity: "medium",
          details: "Transfer of 180 ETH to exchange address",
          timestamp: new Date(Date.now() - 35*60000).toISOString()
        }],
        suspiciousActivity: false
      }
    };
  } else {
    // Default response
    return {
      status: "success",
      timestamp,
      command: {
        executed: true,
        duration: "1.2s"
      },
      results: {
        processed: true,
        stored: true,
        insights: "No actionable insights at this time",
        nextSteps: ["Continue monitoring", "Await further instructions"]
      },
      system: {
        memory: "87% available",
        errors: []
      }
    };
  }
}
