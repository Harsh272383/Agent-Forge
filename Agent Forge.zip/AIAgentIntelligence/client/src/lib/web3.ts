import { ethers } from "ethers";

// Initialize the provider based on the network
export const getProvider = (network: string = "ethereum"): ethers.JsonRpcProvider => {
  // For a real app, we would use actual RPC URLs
  // These are just placeholders
  const rpcUrls: Record<string, string> = {
    ethereum: "https://eth-mainnet.g.alchemy.com/v2/your-api-key",
    polygon: "https://polygon-mainnet.g.alchemy.com/v2/your-api-key",
    arbitrum: "https://arb-mainnet.g.alchemy.com/v2/your-api-key",
    optimism: "https://opt-mainnet.g.alchemy.com/v2/your-api-key",
  };

  const url = rpcUrls[network] || rpcUrls.ethereum;
  return new ethers.JsonRpcProvider(url);
};

// Create a wallet with a private key
export const createWalletWithPrivateKey = (privateKey: string): ethers.Wallet => {
  return new ethers.Wallet(privateKey);
};

// Connect wallet to provider
export const connectWalletToProvider = (wallet: ethers.Wallet, network: string = "ethereum"): ethers.Wallet => {
  const provider = getProvider(network);
  return wallet.connect(provider);
};

// Generate a new wallet
export const generateWallet = (): ethers.Wallet => {
  return ethers.Wallet.createRandom();
};

// Send transaction
export const sendTransaction = async (
  wallet: ethers.Wallet,
  toAddress: string,
  amount: string
): Promise<ethers.TransactionResponse> => {
  const tx = {
    to: toAddress,
    value: ethers.parseEther(amount)
  };
  
  return await wallet.sendTransaction(tx);
};

// Get token balance
export const getTokenBalance = async (
  tokenAddress: string,
  walletAddress: string,
  network: string = "ethereum"
): Promise<string> => {
  const provider = getProvider(network);
  
  // Standard ERC20 ABI for balanceOf
  const abi = [
    "function balanceOf(address owner) view returns (uint256)"
  ];
  
  const tokenContract = new ethers.Contract(tokenAddress, abi, provider);
  const balance = await tokenContract.balanceOf(walletAddress);
  
  return ethers.formatUnits(balance, 18); // Assuming 18 decimals
};

// Get ETH balance
export const getEthBalance = async (
  walletAddress: string,
  network: string = "ethereum"
): Promise<string> => {
  const provider = getProvider(network);
  const balance = await provider.getBalance(walletAddress);
  return ethers.formatEther(balance);
};

// Create contract instance
export const getContract = (
  contractAddress: string,
  contractAbi: ethers.InterfaceAbi,
  network: string = "ethereum"
): ethers.Contract => {
  const provider = getProvider(network);
  return new ethers.Contract(contractAddress, contractAbi, provider);
};

// Sign message
export const signMessage = async (
  wallet: ethers.Wallet,
  message: string
): Promise<string> => {
  return await wallet.signMessage(message);
};

// Connect to metamask (browser wallet)
export const connectToMetaMask = async (): Promise<string | null> => {
  if (window.ethereum) {
    try {
      // Request account access
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      return accounts[0];
    } catch (error) {
      console.error("User denied account access");
      return null;
    }
  } else {
    console.error("MetaMask not detected");
    return null;
  }
};

// Listen for blockchain events
export const listenForEvents = (
  contract: ethers.Contract,
  eventName: string,
  callback: (...args: any[]) => void
): void => {
  contract.on(eventName, callback);
};

// Stop listening to events
export const stopListeningForEvents = (
  contract: ethers.Contract,
  eventName: string
): void => {
  contract.removeAllListeners(eventName);
};

// Get transaction receipt
export const getTransactionReceipt = async (
  txHash: string,
  network: string = "ethereum"
): Promise<ethers.TransactionReceipt | null> => {
  const provider = getProvider(network);
  return await provider.getTransactionReceipt(txHash);
};

// Check if transaction is confirmed
export const isTransactionConfirmed = async (
  txHash: string,
  confirmations: number = 1,
  network: string = "ethereum"
): Promise<boolean> => {
  const provider = getProvider(network);
  const tx = await provider.getTransaction(txHash);
  
  if (!tx) return false;
  
  const receipt = await tx.wait(confirmations);
  return !!receipt;
};

// Types for window.ethereum
declare global {
  interface Window {
    ethereum?: {
      request: (args: {method: string, params?: any[]}) => Promise<any>
      on: (event: string, callback: (...args: any[]) => void) => void
      removeListener: (event: string, callback: (...args: any[]) => void) => void
    }
  }
}
