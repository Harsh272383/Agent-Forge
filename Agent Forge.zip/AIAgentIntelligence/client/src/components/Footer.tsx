import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="mt-10 border-t border-cardBorder py-6 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="h-8 w-8 bg-neonBlue bg-opacity-20 rounded-lg flex items-center justify-center mr-2">
              <i className="ri-robot-fill text-neonBlue text-xl"></i>
            </div>
            <span className="font-display font-bold text-white text-xl">AgentForge</span>
          </div>
          
          <div className="flex space-x-6 mb-4 md:mb-0">
            <Link href="/docs" className="text-textLight hover:text-white transition-colors">
              Documentation
            </Link>
            <Link href="/api" className="text-textLight hover:text-white transition-colors">
              API
            </Link>
            <Link href="/community" className="text-textLight hover:text-white transition-colors">
              Community
            </Link>
            <Link href="/support" className="text-textLight hover:text-white transition-colors">
              Support
            </Link>
          </div>
          
          <div className="flex space-x-4">
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="p-2 rounded-full bg-cardBg hover:bg-neonBlue/20 transition-colors">
              <i className="ri-twitter-x-line text-textLight hover:text-white transition-colors"></i>
            </a>
            <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="p-2 rounded-full bg-cardBg hover:bg-neonBlue/20 transition-colors">
              <i className="ri-github-fill text-textLight hover:text-white transition-colors"></i>
            </a>
            <a href="https://discord.com" target="_blank" rel="noopener noreferrer" className="p-2 rounded-full bg-cardBg hover:bg-neonBlue/20 transition-colors">
              <i className="ri-discord-fill text-textLight hover:text-white transition-colors"></i>
            </a>
            <a href="https://telegram.org" target="_blank" rel="noopener noreferrer" className="p-2 rounded-full bg-cardBg hover:bg-neonBlue/20 transition-colors">
              <i className="ri-telegram-fill text-textLight hover:text-white transition-colors"></i>
            </a>
          </div>
        </div>
        
        <div className="mt-6 pt-6 border-t border-cardBorder text-center md:text-left">
          <p className="text-sm text-textLight opacity-70">
            &copy; {new Date().getFullYear()} AgentForge. All rights reserved. Use of this platform is subject to our Terms of Service and Privacy Policy.
          </p>
        </div>
      </div>
    </footer>
  );
}
