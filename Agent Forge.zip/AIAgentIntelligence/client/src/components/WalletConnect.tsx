import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface WalletConnectProps {
  connected: boolean;
  address: string | null;
  onConnect: () => void;
}

export default function WalletConnect({ connected, address, onConnect }: WalletConnectProps) {
  const { toast } = useToast();

  const handleConnect = () => {
    if (connected) {
      // Display wallet menu or disconnect option
      toast({
        title: "Wallet Connected",
        description: `Connected to ${address}`,
      });
    } else {
      onConnect();
    }
  };

  return (
    <div
      onClick={handleConnect}
      className="flex items-center space-x-2 bg-cardBg px-3 py-1.5 rounded-full border border-cardBorder hover:border-neonBlue transition cursor-pointer"
    >
      <div className={`h-2 w-2 rounded-full ${connected ? 'bg-neonGreen' : 'bg-destructive'}`}></div>
      <span className="text-xs font-medium">
        {connected ? address : "Connect Wallet"}
      </span>
    </div>
  );
}
