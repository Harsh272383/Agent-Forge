import { useEffect, useState } from "react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Agent } from "@/lib/types";
import { cn } from "@/lib/utils";

export default function ActiveAgentStats() {
  const { data: agents, isLoading, error } = useQuery<Agent[]>({
    queryKey: ['/api/agents/active'],
  });

  if (isLoading) {
    return (
      <Card className="glass-card rounded-xl">
        <CardContent className="p-5">
          <h2 className="font-display font-medium text-lg text-white mb-5">Active Agents</h2>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-cardBg rounded-lg p-4 border border-cardBorder animate-pulse">
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-neonBlue bg-opacity-20 mr-3"></div>
                    <div className="h-4 w-24 bg-muted rounded"></div>
                  </div>
                  <div className="h-4 w-16 bg-muted rounded"></div>
                </div>
                <div className="h-3 w-32 bg-muted rounded mb-3"></div>
                <div className="mb-2">
                  <div className="flex justify-between text-xs mb-1">
                    <div className="h-2 w-20 bg-muted rounded"></div>
                    <div className="h-2 w-8 bg-muted rounded"></div>
                  </div>
                  <div className="w-full h-1.5 bg-bgDark rounded-full"></div>
                </div>
                <div className="flex justify-between">
                  <div className="h-2 w-24 bg-muted rounded"></div>
                  <div className="h-2 w-24 bg-muted rounded"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="glass-card rounded-xl">
        <CardContent className="p-5">
          <h2 className="font-display font-medium text-lg text-white mb-5">Active Agents</h2>
          <div className="text-center py-8 text-destructive">
            <p>Error loading agent data</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-card rounded-xl">
      <CardContent className="p-5">
        <h2 className="font-display font-medium text-lg text-white mb-5">Active Agents</h2>
        
        {/* Agent Stats List */}
        <div className="space-y-4">
          {agents && agents.length > 0 ? (
            agents.map((agent) => (
              <Link key={agent.id} href={`/agents/${agent.id}`}>
                <div className="bg-cardBg rounded-lg p-4 border border-cardBorder hover:border-neonBlue transition-all cursor-pointer">
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center">
                      <div className={cn(
                        "w-8 h-8 rounded-full bg-opacity-20 flex items-center justify-center mr-3",
                        agent.agentType === "data" ? "bg-neonBlue" : 
                        agent.agentType === "trader" ? "bg-neonPurple" : 
                        agent.agentType === "monitor" ? "bg-warning" : "bg-neonGreen"
                      )}>
                        <i className={cn(
                          agent.agentType === "data" ? "ri-robot-line text-neonBlue" : 
                          agent.agentType === "trader" ? "ri-exchange-funds-line text-neonPurple" : 
                          agent.agentType === "monitor" ? "ri-alert-line text-warning" : "ri-cpu-line text-neonGreen"
                        )}></i>
                      </div>
                      <span className="font-medium">{agent.name}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <div className={cn(
                        "w-2 h-2 rounded-full",
                        agent.status === "active" ? "bg-neonGreen" : 
                        agent.status === "processing" ? "bg-warning animate-pulse" : "bg-destructive"
                      )}></div>
                      <span className="text-xs">{agent.status === "active" ? "Online" : agent.status === "processing" ? "Working" : "Offline"}</span>
                    </div>
                  </div>
                  <div className="flex items-center text-xs opacity-70 mb-3">
                    <i className="ri-ethereum-line mr-1"></i>
                    <span>{agent.walletAddress}</span>
                  </div>
                  <div className="mb-2">
                    <div className="flex justify-between text-xs mb-1">
                      <span>
                        {agent.agentType === "data" ? "Tasks Completed" : 
                         agent.agentType === "trader" ? "Trade Success Rate" : 
                         agent.agentType === "monitor" ? "Alerts Generated" : "Execution Rate"}
                      </span>
                      <span>
                        {agent.agentType === "trader" ? 
                          `${agent.performanceData?.successRate || 0}%` : 
                          `${agent.performanceData?.tasksCompleted || 0}${agent.agentType === "monitor" ? "" : "/30"}`}
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-bgDark rounded-full overflow-hidden">
                      <div 
                        className="progress-bar h-full rounded-full" 
                        style={{ 
                          width: `${agent.agentType === "trader" ? 
                                    agent.performanceData?.successRate : 
                                    agent.agentType === "monitor" ? 
                                    (agent.performanceData?.alertsGenerated || 0) * 10 : 
                                    ((agent.performanceData?.tasksCompleted || 0) / 30) * 100}%` 
                        }}
                      ></div>
                    </div>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span>Uptime: {agent.performanceData?.uptime || "0h"}</span>
                    <span>Balance: {agent.balance} ETH</span>
                  </div>
                </div>
              </Link>
            ))
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <p>No active agents found</p>
              <Link href="/create-agent">
                <Button variant="outline" className="mt-4">Create your first agent</Button>
              </Link>
            </div>
          )}
        </div>
        
        <Link href="/my-agents">
          <Button variant="outline" className="w-full mt-4 py-2 rounded-lg border border-cardBorder text-sm hover:border-neonBlue transition-all">
            View All Agents
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
