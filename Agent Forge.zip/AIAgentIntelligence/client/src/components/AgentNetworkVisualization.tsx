import { useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Agent } from "@/lib/types";

interface AgentNetworkVisualizationProps {
  agents?: Agent[];
}

export default function AgentNetworkVisualization({ agents = [] }: AgentNetworkVisualizationProps) {
  const networkRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Simulate network activity
    const updateNetworkActivity = () => {
      if (!networkRef.current) return;
      
      const nodes = networkRef.current.querySelectorAll('.agent-node');
      if (nodes.length === 0) return;
      
      const randomIndex = Math.floor(Math.random() * nodes.length);
      const randomNode = nodes[randomIndex] as HTMLElement;
      
      randomNode.classList.add('animate-pulse');
      
      setTimeout(() => {
        randomNode.classList.remove('animate-pulse');
      }, 2000);
    };
    
    // Update network activity periodically
    const interval = setInterval(updateNetworkActivity, 5000);
    
    return () => clearInterval(interval);
  }, []);

  const handleRefresh = () => {
    // In a real app, this would refresh agent data
    console.log("Refreshing agent network...");
  };

  const handleFullscreen = () => {
    // In a real app, this would expand the visualization
    console.log("Expanding visualization to fullscreen...");
  };

  return (
    <Card className="col-span-1 lg:col-span-2 glass-card rounded-xl">
      <CardContent className="p-5 relative overflow-hidden h-[400px]">
        <div className="flex justify-between items-center mb-5">
          <h2 className="font-display font-medium text-lg text-white">Agent Network</h2>
          <div className="flex space-x-2">
            <Button onClick={handleRefresh} variant="outline" size="icon" className="p-1.5 rounded-md bg-cardBg hover:bg-opacity-80 transition">
              <i className="ri-refresh-line text-textLight"></i>
            </Button>
            <Button onClick={handleFullscreen} variant="outline" size="icon" className="p-1.5 rounded-md bg-cardBg hover:bg-opacity-80 transition">
              <i className="ri-fullscreen-line text-textLight"></i>
            </Button>
          </div>
        </div>

        {/* Network Visualization */}
        <div ref={networkRef} className="network-grid w-full h-[310px] rounded-lg relative">
          {/* Main Agent Node */}
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 agent-node w-16 h-16 rounded-full bg-neonBlue bg-opacity-20 border border-neonBlue flex items-center justify-center z-20 animate-float">
            <div className="relative">
              <i className="ri-brain-line text-2xl text-neonBlue"></i>
              <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-neonGreen agent-pulse"></div>
            </div>
          </div>
          
          {/* Node 1 */}
          <div className="absolute top-[30%] left-[25%] agent-node w-12 h-12 rounded-full bg-neonPurple bg-opacity-20 border border-neonPurple flex items-center justify-center">
            <i className="ri-database-2-line text-lg text-neonPurple"></i>
          </div>
          {/* Connection Line 1 */}
          <div className="absolute top-[38%] left-[33%] w-[150px] h-[1px] bg-neonPurple opacity-50 rotate-45 transform origin-left"></div>
          
          {/* Node 2 */}
          <div className="absolute top-[20%] left-[60%] agent-node w-12 h-12 rounded-full bg-neonGreen bg-opacity-20 border border-neonGreen flex items-center justify-center">
            <i className="ri-coin-line text-lg text-neonGreen"></i>
          </div>
          {/* Connection Line 2 */}
          <div className="absolute top-[28%] left-[56%] w-[80px] h-[1px] bg-neonGreen opacity-50 rotate-[-45deg] transform origin-left"></div>
          
          {/* Node 3 */}
          <div className="absolute top-[70%] left-[30%] agent-node w-12 h-12 rounded-full bg-warning bg-opacity-20 border border-warning flex items-center justify-center">
            <i className="ri-eye-line text-lg text-warning"></i>
          </div>
          {/* Connection Line 3 */}
          <div className="absolute top-[62%] left-[35%] w-[120px] h-[1px] bg-warning opacity-50 rotate-[-45deg] transform origin-left"></div>
          
          {/* Node 4 */}
          <div className="absolute top-[65%] left-[70%] agent-node w-12 h-12 rounded-full bg-neonBlue bg-opacity-20 border border-neonBlue flex items-center justify-center">
            <i className="ri-message-3-line text-lg text-neonBlue"></i>
          </div>
          {/* Connection Line 4 */}
          <div className="absolute top-[58%] left-[65%] w-[100px] h-[1px] bg-neonBlue opacity-50 rotate-45 transform origin-left"></div>
          
          {/* Activity Indicators */}
          <div className="absolute bottom-3 left-3 flex items-center space-x-5 text-xs">
            <div className="flex items-center">
              <div className="w-2 h-2 rounded-full bg-neonGreen mr-2"></div>
              <span>Active</span>
            </div>
            <div className="flex items-center">
              <div className="w-2 h-2 rounded-full bg-warning mr-2"></div>
              <span>Processing</span>
            </div>
            <div className="flex items-center">
              <div className="w-2 h-2 rounded-full bg-neonPurple mr-2"></div>
              <span>Idle</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
