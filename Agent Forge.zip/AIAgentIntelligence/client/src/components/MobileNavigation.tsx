import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

export default function MobileNavigation() {
  const [location] = useLocation();

  const navItems = [
    { path: "/", label: "Dashboard", icon: "ri-dashboard-line" },
    { path: "/marketplace", label: "Marketplace", icon: "ri-store-2-line" },
    { path: "/my-agents", label: "My Agents", icon: "ri-robot-line" },
    { path: "/profile", label: "Profile", icon: "ri-user-line" },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-bgNavy bg-opacity-95 backdrop-blur-md border-t border-cardBorder z-50">
      <div className="flex justify-around items-center h-16 px-4">
        {navItems.map((item) => (
          <Link 
            href={item.path} 
            key={item.path}
            className={cn(
              "flex flex-col items-center",
              location === item.path ? "text-neonBlue" : "text-textLight"
            )}>
              <i className={cn(item.icon, "text-xl")}></i>
              <span className="text-xs mt-1">{item.label}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
