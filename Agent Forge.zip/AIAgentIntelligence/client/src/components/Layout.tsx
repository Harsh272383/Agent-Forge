import { useState } from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";
import MobileNavigation from "./MobileNavigation";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [walletConnected, setWalletConnected] = useState(false);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);

  const handleConnectWallet = async () => {
    try {
      // In a real app, this would use ethers.js or web3.js to connect
      // For demo purposes, we'll simulate a connected wallet
      setWalletAddress("0x8f...3e4a");
      setWalletConnected(true);
    } catch (error) {
      console.error("Error connecting wallet:", error);
    }
  };

  return (
    <div className="relative min-h-screen flex flex-col">
      <Navbar 
        walletConnected={walletConnected} 
        walletAddress={walletAddress}
        onConnectWallet={handleConnectWallet}
      />
      
      <main className="flex-grow px-4 py-6 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        {children}
      </main>
      
      <Footer />
      
      {/* Mobile Navigation (only visible on small screens) */}
      <MobileNavigation />
    </div>
  );
}
