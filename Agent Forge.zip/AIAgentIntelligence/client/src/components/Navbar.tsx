import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import WalletConnect from "./WalletConnect";

interface NavbarProps {
  walletConnected: boolean;
  walletAddress: string | null;
  onConnectWallet: () => void;
}

export default function Navbar({ walletConnected, walletAddress, onConnectWallet }: NavbarProps) {
  const [location] = useLocation();

  const navItems = [
    { path: "/", label: "Dashboard" },
    { path: "/marketplace", label: "Marketplace" },
    { path: "/my-agents", label: "My Agents" },
    { path: "/analytics", label: "Analytics" },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-bgNavy bg-opacity-90 backdrop-blur-md border-b border-cardBorder">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <div className="h-8 w-8 bg-neonBlue bg-opacity-20 rounded-lg flex items-center justify-center mr-2 cursor-pointer">
                  <i className="ri-robot-fill text-neonBlue text-xl"></i>
                </div>
              </Link>
              <Link href="/">
                <span className="font-display font-bold text-white text-xl cursor-pointer">AgentForge</span>
              </Link>
            </div>
            <div className="hidden md:ml-8 md:flex md:space-x-6">
              {navItems.map((item) => (
                <Link 
                  href={item.path} 
                  key={item.path}
                  className={cn(
                    "px-1 pt-1 text-sm font-medium border-b-2",
                    location === item.path 
                      ? "text-white border-neonBlue"
                      : "text-textLight hover:text-white border-transparent hover:border-neonPurple"
                  )}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <WalletConnect 
              connected={walletConnected}
              address={walletAddress}
              onConnect={onConnectWallet}
            />
            <button className="p-2 rounded-full bg-cardBg hover:bg-opacity-80 transition">
              <i className="ri-notification-3-line text-textLight"></i>
            </button>
            <button className="p-2 rounded-full bg-cardBg hover:bg-opacity-80 transition">
              <i className="ri-settings-3-line text-textLight"></i>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
