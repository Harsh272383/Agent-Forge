import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

// Form schema
const formSchema = z.object({
  name: z.string().min(1, "Name is required"),
  agentType: z.string().min(1, "Agent type is required"),
  description: z.string().optional(),
  initialFunding: z.coerce.number().min(0, "Funding must be a positive number"),
  networks: z.array(z.string()).min(1, "Select at least one network"),
});

type FormValues = z.infer<typeof formSchema>;

export default function CreateAgentForm() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const [selectedNetworks, setSelectedNetworks] = useState<string[]>(["ethereum"]);
  
  // Form setup
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      agentType: "",
      description: "",
      initialFunding: 0.05,
      networks: ["ethereum"],
    },
  });
  
  const toggleNetwork = (network: string) => {
    setSelectedNetworks(prev => {
      if (prev.includes(network)) {
        // Don't remove if it's the last network
        if (prev.length === 1) return prev;
        return prev.filter(n => n !== network);
      } else {
        return [...prev, network];
      }
    });
    
    form.setValue("networks", selectedNetworks);
  };
  
  const onSubmit = async (data: FormValues) => {
    try {
      // Create agent payload
      const payload = {
        name: data.name,
        agentType: data.agentType,
        description: data.description || `${data.name} - ${data.agentType} agent`,
        status: "inactive", // Start inactive until configured
        networks: selectedNetworks,
        balance: data.initialFunding,
        config: {
          // Default configs based on agent type
          ...(data.agentType === "trader" && {
            supportedTokens: ["ETH", "USDT", "USDC"],
            riskLevel: "medium",
          }),
          ...(data.agentType === "monitor" && {
            alertThreshold: "medium",
            notificationChannels: ["email"],
          }),
          ...(data.agentType === "data" && {
            dataTypes: ["transactions", "events"],
            storageType: "ipfs",
          }),
        },
        performanceData: {},
        initialize: true, // Flag to initialize AI agent
      };
      
      // Create the agent
      const response = await apiRequest("POST", "/api/agents", payload);
      const agent = await response.json();
      
      // Invalidate queries to refresh data
      await queryClient.invalidateQueries({ queryKey: ['/api/agents'] });
      
      toast({
        title: "Agent Created",
        description: `${agent.name} has been created successfully.`,
      });
      
      // Navigate to the agent details page
      setLocation(`/agents/${agent.id}`);
    } catch (error) {
      console.error("Error creating agent:", error);
      toast({
        title: "Creation Failed",
        description: "There was an error creating your agent.",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="glass-card rounded-xl border border-cardBorder">
      <CardContent className="p-5">
        <h3 className="font-display font-medium text-lg text-white mb-4">Quick Agent Setup</h3>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium">Agent Name</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="MyCustomAgent" 
                      className="w-full bg-bgDarker border border-cardBorder rounded-lg px-4 py-2.5 text-white focus:border-neonBlue outline-none transition-colors" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="agentType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium">Agent Type</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="w-full bg-bgDarker border border-cardBorder rounded-lg px-4 py-2.5 text-white focus:border-neonBlue outline-none transition-colors">
                        <SelectValue placeholder="Select agent type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="monitor">Monitor & Alert</SelectItem>
                      <SelectItem value="trader">Trading Bot</SelectItem>
                      <SelectItem value="data">Data Collector</SelectItem>
                      <SelectItem value="custom">Custom Logic</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="networks"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium">Networks</FormLabel>
                  <FormControl>
                    <div className="flex flex-wrap gap-2">
                      <div 
                        className={`flex items-center px-3 py-1.5 rounded-lg border cursor-pointer ${
                          selectedNetworks.includes("ethereum") 
                            ? "bg-neonBlue bg-opacity-10 border-neonBlue" 
                            : "bg-bgDarker border-cardBorder hover:border-neonPurple"
                        }`}
                        onClick={() => toggleNetwork("ethereum")}
                      >
                        <img src="https://cryptologos.cc/logos/ethereum-eth-logo.svg" alt="Ethereum" className="w-4 h-4 mr-2" />
                        <span className="text-sm">Ethereum</span>
                      </div>
                      
                      <div 
                        className={`flex items-center px-3 py-1.5 rounded-lg border cursor-pointer ${
                          selectedNetworks.includes("polygon") 
                            ? "bg-neonBlue bg-opacity-10 border-neonBlue" 
                            : "bg-bgDarker border-cardBorder hover:border-neonPurple"
                        }`}
                        onClick={() => toggleNetwork("polygon")}
                      >
                        <img src="https://cryptologos.cc/logos/polygon-matic-logo.svg" alt="Polygon" className="w-4 h-4 mr-2" />
                        <span className="text-sm">Polygon</span>
                      </div>
                      
                      <div 
                        className={`flex items-center px-3 py-1.5 rounded-lg border cursor-pointer ${
                          selectedNetworks.includes("arbitrum") 
                            ? "bg-neonBlue bg-opacity-10 border-neonBlue" 
                            : "bg-bgDarker border-cardBorder hover:border-neonPurple"
                        }`}
                        onClick={() => toggleNetwork("arbitrum")}
                      >
                        <img src="https://cryptologos.cc/logos/arbitrum-arb-logo.svg" alt="Arbitrum" className="w-4 h-4 mr-2" />
                        <span className="text-sm">Arbitrum</span>
                      </div>
                      
                      <div className="flex items-center px-3 py-1.5 rounded-lg bg-bgDarker border border-cardBorder hover:border-neonPurple cursor-pointer">
                        <i className="ri-add-line mr-1"></i>
                        <span className="text-sm">More</span>
                      </div>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="initialFunding"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium">Initial Funding (ETH)</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      step="0.01"
                      placeholder="0.05" 
                      className="w-full bg-bgDarker border border-cardBorder rounded-lg px-4 py-2.5 text-white focus:border-neonBlue outline-none transition-colors" 
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              className="w-full mt-5 py-2.5 rounded-lg bg-gradient-to-r from-neonBlue to-neonPurple text-white font-medium hover:shadow-lg hover:shadow-neonBlue/20 transition-all"
            >
              Start Building
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
