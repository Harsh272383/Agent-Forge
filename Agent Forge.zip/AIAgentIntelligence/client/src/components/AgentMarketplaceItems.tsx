import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { AgentTemplate } from "@/lib/types";
import { queryClient } from "@/lib/queryClient";

interface AgentMarketplaceItemsProps {
  limit?: number;
  showViewAll?: boolean;
}

export default function AgentMarketplaceItems({ limit = 4, showViewAll = true }: AgentMarketplaceItemsProps) {
  const { toast } = useToast();
  
  const { data: templates, isLoading, error } = useQuery<AgentTemplate[]>({
    queryKey: ['/api/agent-templates/popular'],
  });

  const handleDeploy = async (templateId: number) => {
    try {
      const response = await apiRequest('POST', `/api/agent-templates/${templateId}/deploy`, {});
      
      // Invalidate queries to refresh data
      await queryClient.invalidateQueries({ queryKey: ['/api/agents'] });
      
      toast({
        title: "Agent Deployed",
        description: "The agent template has been successfully deployed.",
      });
    } catch (error) {
      console.error("Error deploying template:", error);
      toast({
        title: "Deployment Failed",
        description: "Failed to deploy the agent template.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {Array.from({ length: limit }).map((_, i) => (
          <div key={i} className="glass-card rounded-xl overflow-hidden animate-pulse">
            <div className="h-40 bg-muted"></div>
            <div className="p-5">
              <div className="h-5 w-32 bg-muted rounded mb-2"></div>
              <div className="h-3 w-full bg-muted rounded mb-2"></div>
              <div className="h-3 w-full bg-muted rounded mb-3"></div>
              <div className="flex justify-between mb-4">
                <div className="h-3 w-24 bg-muted rounded"></div>
                <div className="h-3 w-24 bg-muted rounded"></div>
              </div>
              <div className="flex justify-between items-center">
                <div className="h-4 w-16 bg-muted rounded"></div>
                <div className="h-8 w-20 bg-muted rounded"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8 text-destructive">
        <p>Error loading marketplace data</p>
      </div>
    );
  }

  return (
    <div className="mt-8">
      <div className="flex justify-between items-center mb-5">
        <h2 className="font-display font-medium text-xl text-white">Agent Marketplace</h2>
        {showViewAll && (
          <Link href="/marketplace">
            <Button variant="link" className="text-sm text-neonBlue hover:text-neonPurple transition-colors">
              View All <i className="ri-arrow-right-line ml-1"></i>
            </Button>
          </Link>
        )}
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {templates && templates.length > 0 ? (
          templates.slice(0, limit).map((template) => (
            <div key={template.id} className="glass-card rounded-xl overflow-hidden group hover:border-neonBlue transition-all">
              {/* Template Image */}
              <div className="h-40 bg-gradient-to-br from-neonPurple/30 to-neonBlue/30 relative overflow-hidden">
                <img 
                  src={template.imagePath} 
                  alt={template.name} 
                  className="w-full h-full object-cover opacity-70 group-hover:scale-105 transition-transform duration-500" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-bgNavy via-transparent to-transparent"></div>
                {template.isPopular && (
                  <div className="absolute top-3 right-3 bg-neonGreen/90 text-bgDark text-xs font-medium px-2 py-1 rounded-full">
                    Popular
                  </div>
                )}
                {template.isNew && (
                  <div className="absolute top-3 right-3 bg-neonPurple/90 text-white text-xs font-medium px-2 py-1 rounded-full">
                    New
                  </div>
                )}
              </div>
              
              <div className="p-5">
                <h3 className="font-display font-medium text-white mb-1 group-hover:text-neonBlue transition-colors">{template.name}</h3>
                <p className="text-sm text-textLight opacity-70 mb-3 line-clamp-2">
                  {template.description}
                </p>
                
                <div className="flex items-center text-xs mb-4">
                  <div className="flex items-center mr-3">
                    <i className="ri-download-line mr-1 text-neonBlue"></i>
                    <span>{template.downloads} Deploys</span>
                  </div>
                  <div className="flex items-center">
                    <i className="ri-star-fill mr-1 text-warning"></i>
                    <span>{template.rating.toFixed(1)} ({template.reviewCount})</span>
                  </div>
                </div>
                
                <div className="flex justify-between items-center">
                  <div>
                    <span className="block text-xs opacity-70">Price</span>
                    <div className="flex items-center">
                      <i className="ri-ethereum-line mr-1 text-neonPurple"></i>
                      <span className="font-medium">{template.price} ETH</span>
                    </div>
                  </div>
                  <Button
                    onClick={() => handleDeploy(template.id)}
                    className="px-3 py-1.5 rounded-lg bg-neonBlue bg-opacity-20 border border-neonBlue text-neonBlue text-sm hover:bg-opacity-30 transition-all"
                  >
                    Deploy
                  </Button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full text-center py-8 text-muted-foreground">
            <p>No templates available</p>
          </div>
        )}
      </div>
    </div>
  );
}
